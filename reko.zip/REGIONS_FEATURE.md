# Hoda Scripts — Screen Regions

Added in v0.13.0:
- Named screen-region library.
- Full-screen drag selector returning screen X/Y/width/height.
- Per-region tap duration, swipe duration, repetition count and interval.
- Region detail/editor screen matching the existing shortcut editor style.
- Region execution through the existing user-enabled Accessibility service.
- Hold gesture support in HodaAccessibilityService.

Safety:
- No root command is executed automatically.
- Accessibility remains explicitly user-enabled.
- Existing shortcut storage and engine were not replaced.
- Region data is stored separately from shortcut data.
