package com.hoda.scripts.engine;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import com.hoda.scripts.MainActivity;
import com.hoda.scripts.model.Shortcut;
import org.json.JSONArray;
import java.util.Map;

/** User-visible foreground host for automation sessions explicitly enabled by the user. */
public class AutomationService extends Service {
    public static final String ACTION_START = "com.hoda.scripts.action.START_AUTOMATION";
    public static final String ACTION_STOP = "com.hoda.scripts.action.STOP_AUTOMATION";
    private static final String CHANNEL = "hoda_automation";
    private static final int NOTIFICATION_ID = 4101;
    private static final int RESULT_NOTIFICATION_ID = 4102;
    public static final String ACTION_RUN_SHORTCUT = "com.hoda.scripts.action.RUN_SHORTCUT";
    public static final String EXTRA_SHORTCUT_NAME = "shortcut_name";
    public static final String EXTRA_SHORTCUT_ACTIONS = "shortcut_actions";
    private ShortcutExecutionEngine engine;
    private String runningName = "Hoda Scripts";

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Hoda automation", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows shortcut progress and controls while Hoda Scripts runs in the background");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            cancelCurrentRun();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        Notification notification = buildRunningNotification("Preparing background automation");
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTIFICATION_ID, notification);
        if (intent != null && ACTION_RUN_SHORTCUT.equals(intent.getAction())) runShortcut(intent);
        return START_NOT_STICKY;
    }

    private Notification buildRunningNotification(String message) {
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 4101, open, pendingFlags());
        Intent stop = new Intent(this, AutomationService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(this, 4102, stop, pendingFlags());
        Notification.Builder builder = builder().setSmallIcon(android.R.drawable.ic_popup_sync)
                .setContentTitle(runningName).setContentText(message).setContentIntent(content)
                .setOngoing(true).setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_media_pause, "Stop", stopAction);
        return builder.build();
    }

    private Notification.Builder builder() {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
    }

    private int pendingFlags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    private void runShortcut(Intent intent) {
        if (engine != null) engine.cancel();
        String name = intent.getStringExtra(EXTRA_SHORTCUT_NAME);
        String raw = intent.getStringExtra(EXTRA_SHORTCUT_ACTIONS);
        if (raw == null) { stopForeground(true); stopSelf(); return; }
        runningName = name == null ? "Hoda Scripts" : name;
        updateForeground("Starting " + runningName);
        try {
            Shortcut shortcut = new Shortcut(0, runningName, "#EAE5FF", "⚡", new JSONArray(raw), System.currentTimeMillis());
            engine = new ShortcutExecutionEngine(getApplicationContext(), shortcut, new ShortcutExecutionEngine.Listener() {
                @Override public void onStarted(String n) { updateForeground("Running shortcut"); }
                @Override public void onProgress(int completed, int total, String title) { updateForeground(title + " · " + completed + "/" + total); }
                @Override public void onFinished(Map<String,Object> variables) {
                    Object result = variables.get("result");
                    String detail = result == null ? "Shortcut completed" : "Completed · " + String.valueOf(result);
                    com.hoda.scripts.data.RunHistoryStore.add(AutomationService.this, runningName, true, detail);
                    finishRun(true, detail);
                }
                @Override public void onError(String title, String message) {
                    String detail = "Failed: " + title + " — " + message;
                    com.hoda.scripts.data.RunHistoryStore.add(AutomationService.this, runningName, false, detail);
                    finishRun(false, detail);
                }
            });
            engine.start();
        } catch (Exception e) {
            com.hoda.scripts.data.RunHistoryStore.add(this, runningName, false, "Could not start: " + e.getMessage());
            finishRun(false, "Could not start: " + e.getMessage());
        }
    }

    private void updateForeground(String message) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildRunningNotification(message));
    }

    private void finishRun(boolean success, String message) {
        engine = null;
        stopForeground(true);
        postResultNotification(success, message);
        stopSelf();
    }

    private void postResultNotification(boolean success, String message) {
        Notification notification = builder().setSmallIcon(success ? android.R.drawable.checkbox_on_background : android.R.drawable.stat_notify_error)
                .setContentTitle(runningName).setContentText(message).setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(this, 4103, new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP), pendingFlags()))
                .build();
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(RESULT_NOTIFICATION_ID, notification);
    }

    private void cancelCurrentRun() {
        if (engine != null) { engine.cancel(); engine = null; }
    }

    @Override public void onDestroy() { cancelCurrentRun(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
