package com.hoda.scripts.automation;

import android.content.Context;
import android.content.Intent;
import com.hoda.scripts.data.ShortcutStore;
import com.hoda.scripts.engine.AutomationService;
import com.hoda.scripts.model.Shortcut;

/** Starts a user-configured shortcut through the visible foreground execution service. */
public final class AutomationRunner {
    private AutomationRunner(){}
    public static boolean run(Context context,long shortcutId){
        ShortcutStore store=new ShortcutStore(context);Shortcut s=store.get(shortcutId);store.close();if(s==null)return false;
        Intent i=new Intent(context,AutomationService.class);i.setAction(AutomationService.ACTION_RUN_SHORTCUT);i.putExtra(AutomationService.EXTRA_SHORTCUT_NAME,s.name);i.putExtra(AutomationService.EXTRA_SHORTCUT_ACTIONS,s.actions.toString());
        try{if(android.os.Build.VERSION.SDK_INT>=26)context.startForegroundService(i);else context.startService(i);return true;}catch(Exception e){return false;}
    }
}
