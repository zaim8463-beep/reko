package com.hoda.scripts.engine;

import java.util.Arrays;
import java.util.List;

/** Discoverable action definitions used by the visual editor. Execution support is implemented by the engine in a later milestone. */
public final class ActionCatalog {
    private ActionCatalog() {}
    public static class Definition {
        public final String id, category, title, description;
        public Definition(String i,String c,String t,String d){id=i;category=c;title=t;description=d;}
    }
    public static List<Definition> all(){ return Arrays.asList(
        new Definition("text","Text","Text","Create text for the next action"),
        new Definition("ask_input","Text","Ask for Input","Ask the user to enter text or a number"),
        new Definition("clipboard","Text","Copy to Clipboard","Copy text to the system clipboard"),
        new Definition("get_clipboard","Text","Get Clipboard","Read clipboard text when Android permits it"),
        new Definition("wait","Scripting","Wait","Pause the workflow for a duration in milliseconds"),
        new Definition("if","Scripting","If","Run a branch when a condition is true"),
        new Definition("repeat","Scripting","Repeat","Repeat a group of actions a fixed number of times"),
        new Definition("repeat_each","Scripting","Repeat with Each","Run actions once for each item in a list"),
        new Definition("choose_menu","Scripting","Choose from Menu","Let the user choose one of several branches"),
        new Definition("set_variable","Scripting","Set Variable","Store a value for later actions"),
        new Definition("get_variable","Scripting","Get Variable","Read a previously stored value"),
        new Definition("list","Scripting","List","Create a list of values"),
        new Definition("dictionary","Scripting","Dictionary","Create key-value data"),
        new Definition("url","Web","Open URL","Open a web address in another app"),
        new Definition("http_get","Web","Get Contents of URL","Make an HTTP GET request"),
        new Definition("http_post","Web","Post Contents of URL","Send data using an HTTP POST request"),
        new Definition("json_parse","Web","Get Dictionary from Input","Parse JSON text into structured data"),
        new Definition("notification","Device","Show Notification","Display a notification"),
        new Definition("brightness","Device","Set Brightness","Change screen brightness with system permission"),
        new Definition("vibrate","Device","Vibrate Device","Trigger a short vibration"),
        new Definition("open_app","Apps","Open App","Launch an installed application by package name"),
        new Definition("plugin_intent","Integrations","App Integration","Open a supported deep link or share text with another app"),
        new Definition("accessibility_global","Accessibility","System Navigation Action","Run Back, Home, Recents, Notifications, Quick Settings or Power dialog after the user enables the service"),
        new Definition("accessibility_tap","Accessibility","Tap Screen Coordinates","Tap a screen coordinate using an explicit user-enabled accessibility service"),
        new Definition("share","Sharing","Share","Send content to another app using Android Sharesheet"),
        new Definition("file_read","Files","Get File","Read a file selected by the user"),
        new Definition("file_write","Files","Save File","Save text or data to a user-selected location"),
        new Definition("pick_image","Files","Select Image","Choose an image using Android's document picker"),
        new Definition("pick_video","Files","Select Video","Choose a video using Android's document picker"),
        new Definition("pick_audio","Files","Select Audio","Choose an audio file using Android's document picker"),
        new Definition("pick_pdf","Files","Select PDF","Choose a PDF document"),
        new Definition("file_info","Files","Get File Details","Read metadata for a selected file"),
        new Definition("open_file","Files","Open File","Open a selected file in a compatible app"),
        new Definition("share_file","Sharing","Share File","Share a selected file with another app"),
        new Definition("json_stringify","Data","Encode JSON","Convert structured data to JSON text"),
        new Definition("list_count","Data","Count Items","Count items in a list"),
        new Definition("list_get","Data","Get List Item","Get an item by zero-based index"),
        new Definition("list_append","Data","Add to List","Append a value to a list variable")
    ); }
}
