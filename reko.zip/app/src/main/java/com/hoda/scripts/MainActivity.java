package com.hoda.scripts;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import com.hoda.scripts.data.ShortcutStore;
import com.hoda.scripts.data.RegionStore;
import com.hoda.scripts.model.ScreenRegion;
import com.hoda.scripts.engine.ActionCatalog;
import com.hoda.scripts.model.Shortcut;
import com.hoda.scripts.root.RootAccessManager;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    private ShortcutStore store; private LinearLayout root, content, top; private String page="shortcuts"; private boolean arabic; private final Handler handler=new Handler(Looper.getMainLooper());
    private static final int REQ_NOTIFICATIONS=7201;
    private static final int REQ_VOICE_SHORTCUT=7202;
    private static final int REQ_BACKUP_CREATE=7203;
    private static final int REQ_BACKUP_RESTORE=7204;
    private static final int REQ_REGION_SELECT=7210;
    private com.hoda.scripts.engine.ShortcutExecutionEngine activeEngine;
    private RegionStore regionStore;
    private String libraryFilter="all", libraryFolder="", libraryQuery="", librarySort="recent";
    private EditText librarySearch;
    private int purple=Color.rgb(112,84,231), ink=Color.rgb(30,30,38), muted=Color.rgb(120,120,132), bg=Color.rgb(247,247,251);
    @Override public void onCreate(Bundle b){super.onCreate(b); store=new ShortcutStore(this); regionStore=new RegionStore(this); arabic=getPreferences(0).getBoolean("ar",true); showHome(); handleIncomingShare(getIntent()); handleShortcutLaunch(getIntent());}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handleIncomingShare(intent);handleShortcutLaunch(intent);}
    private void handleShortcutLaunch(Intent intent){if(intent==null)return;long id=intent.getLongExtra("hoda_shortcut_id",0);if(id>0){intent.removeExtra("hoda_shortcut_id");Shortcut shortcut=store.get(id);if(shortcut!=null)handler.postDelayed(()->runShortcut(shortcut),350);}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_BACKUP_CREATE){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null) writeFullBackup(data.getData());
            return;
        }
        if(requestCode==REQ_BACKUP_RESTORE){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null) confirmFullRestore(data.getData());
            return;
        }
        if(requestCode==REQ_REGION_SELECT && resultCode==RESULT_OK && data!=null){
            int x=data.getIntExtra("x",0), y=data.getIntExtra("y",0), w=data.getIntExtra("width",0), h=data.getIntExtra("height",0);
            createRegionFromSelection(x,y,w,h); return;
        }
        if(requestCode==REQ_VOICE_SHORTCUT && resultCode==RESULT_OK && data!=null){
            ArrayList<String> matches=data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
            if(matches!=null&&!matches.isEmpty()) runVoiceMatch(matches.get(0));
            return;
        }
        if(activeEngine!=null)activeEngine.onActivityResult(requestCode,resultCode,data);
    }
    @Override protected void onDestroy(){if(activeEngine!=null)activeEngine.cancel();super.onDestroy();}
    private void handleIncomingShare(Intent intent){
        if(intent==null)return;
        String action=intent.getAction();
        if(Intent.ACTION_SEND.equals(action)){
            CharSequence text=intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if(text!=null){new AlertDialog.Builder(this).setTitle(t("Import shared shortcut","استيراد اختصار تمت مشاركته")).setMessage(t("Import the shared Hoda JSON into your library?","هل تريد استيراد بيانات Hoda التي تمت مشاركتها إلى مكتبتك؟")).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Import","استيراد"),(d,w)->importJson(text.toString())).show();return;}
            Uri stream=intent.getParcelableExtra(Intent.EXTRA_STREAM);if(stream!=null)confirmImportSharedUri(stream);
        } else if(Intent.ACTION_SEND_MULTIPLE.equals(action)){
            ArrayList<Uri> streams=intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if(streams!=null&&!streams.isEmpty()){
                String[] names=new String[streams.size()];for(int i=0;i<streams.size();i++)names[i]=t("Shared file ","ملف مشارك ")+(i+1);
                new AlertDialog.Builder(this).setTitle(t("Shared files","ملفات تمت مشاركتها")).setMessage(t("Choose a JSON file to import, or cancel to leave the files untouched.","اختر ملف JSON لاستيراده، أو ألغِ لترك الملفات دون تغيير.")).setItems(names,(d,w)->confirmImportSharedUri(streams.get(w))).setNegativeButton(t("Cancel","إلغاء"),null).show();
            }
        }
    }
    private void confirmImportSharedUri(Uri uri){new AlertDialog.Builder(this).setTitle(t("Import shared file?","استيراد الملف المشارك؟")).setMessage(t("Only a Hoda JSON shortcut/library file will be imported.","سيتم استيراد ملف اختصار أو مكتبة Hoda بصيغة JSON فقط.")).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Import","استيراد"),(d,w)->{try(java.io.InputStream in=getContentResolver().openInputStream(uri);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){if(in==null)throw new IllegalStateException("Cannot open shared file");byte[] buf=new byte[8192];int n,total=0;while((n=in.read(buf))!=-1){total+=n;if(total>2*1024*1024)throw new IllegalArgumentException("JSON file is too large");out.write(buf,0,n);}importJson(new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8));}catch(Exception ex){Toast.makeText(this,t("Could not import file: ","تعذر استيراد الملف: ")+ex.getMessage(),Toast.LENGTH_LONG).show();}}).show();}
    private String t(String en,String ar){return arabic?ar:en;}
    private TextView label(String s,int size,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(ink);if(bold)v.setTypeface(null,1);return v;}
    private GradientDrawable bg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void base(String title){
        root=column();root.setBackgroundColor(bg);setContentView(root);
        top=column();top.setPadding(22,18,22,12);root.addView(top);
        TextView brand=label("Hoda Scripts",14,true);brand.setTextColor(purple);top.addView(brand);
        TextView heading=label(title,29,true);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=5;top.addView(heading,hp);
        ScrollView scroll=new ScrollView(this);content=column();content.setPadding(18,8,18,26);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row();nav.setBackgroundColor(Color.WHITE);nav.setPadding(5,8,5,8);root.addView(nav);
        addNav(nav,t("Shortcuts","الاختصارات"),"shortcuts");addNav(nav,t("Automation","الأتمتة"),"automation");addNav(nav,t("Gallery","المعرض"),"gallery");addNav(nav,t("Settings","الإعدادات"),"settings");
    }
    private void addNav(LinearLayout nav,String text,String target){TextView v=label(text,11,page.equals(target));v.setGravity(Gravity.CENTER);v.setPadding(4,12,4,12);v.setTextColor(page.equals(target)?purple:muted);nav.addView(v,new LinearLayout.LayoutParams(0,-2,1));v.setOnClickListener(x->{page=target;showPage();});}
    private void showPage(){switch(page){case"automation":showAutomation();break;case"gallery":showGallery();break;case"settings":showSettings();break;case"custom":showCustom();break;case"regions":showRegions();break;default:showHome();}}
    private void card(View v){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=10;v.setBackground(bg(Color.WHITE,22));v.setPadding(16,15,16,15);content.addView(v,p);}
    private TextView button(String text,Runnable action){TextView b=label(text,15,true);b.setTextColor(Color.WHITE);b.setGravity(Gravity.CENTER);b.setPadding(18,14,18,14);b.setBackground(bg(purple,18));b.setOnClickListener(v->action.run());return b;}
    private void showHome(){
        page="shortcuts";base(t("My Shortcuts","اختصاراتي"));
        LinearLayout header=row();
        TextView summary=label(t("Your personal automation library","مكتبتك الشخصية للاختصارات والأتمتة"),13,false);summary.setTextColor(muted);
        header.addView(summary,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(button(t("Import / Export","استيراد / تصدير"),this::showLibraryTools));
        header.addView(button(t("Custom","مخصص"),this::showCustom));
        header.addView(button(t("+ New","+ جديد"),this::newShortcut));content.addView(header);

        librarySearch=new EditText(this);librarySearch.setSingleLine(true);librarySearch.setTextSize(15);
        librarySearch.setHint(t("Search shortcuts","ابحث في الاختصارات"));librarySearch.setCompoundDrawablePadding(8);
        librarySearch.setPadding(14,11,14,11);librarySearch.setBackground(bg(Color.WHITE,15));
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=14;sp.bottomMargin=10;content.addView(librarySearch,sp);
        librarySearch.setText(libraryQuery);
        librarySearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){libraryQuery=s.toString();renderLibraryResults();}public void afterTextChanged(Editable e){}});

        LinearLayout controls=row();
        controls.addView(chip(t("All","الكل"),"all"));controls.addView(chip(t("Favorites","المفضلة"),"favorites"));
        controls.addView(chip(t("Unfiled","بدون مجلد"),"unfiled"));
        controls.addView(button(t("Sort","ترتيب"),this::showSortMenu));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=8;content.addView(controls,cp);

        LinearLayout folderHeader=row();TextView foldersTitle=label(t("Folders","المجلدات"),17,true);folderHeader.addView(foldersTitle,new LinearLayout.LayoutParams(0,-2,1));
        folderHeader.addView(button(t("+ Folder","+ مجلد"),this::createFolderDialog));content.addView(folderHeader);
        LinearLayout folderStrip=row();folderStrip.setPadding(0,8,0,12);
        TextView allFolder=folderChip(t("All shortcuts","كل الاختصارات"),"");folderStrip.addView(allFolder);
        for(String f:store.folders())folderStrip.addView(folderChip("📁 "+f,f));
        content.addView(folderStrip);
        TextView resultsTitle=label(t("Shortcuts","الاختصارات"),20,true);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=6;rp.bottomMargin=8;content.addView(resultsTitle,rp);
        LinearLayout results=column();results.setTag("library_results");content.addView(results);
        renderLibraryResults();
    }

    private TextView chip(String title,String filter){TextView v=label(title,12,true);v.setGravity(Gravity.CENTER);v.setPadding(11,10,11,10);v.setTextColor(libraryFilter.equals(filter)?Color.WHITE:purple);v.setBackground(bg(libraryFilter.equals(filter)?purple:0xffeeeaff,16));v.setOnClickListener(x->{libraryFilter=filter;libraryFolder="";showHome();});return v;}
    private TextView folderChip(String title,String folder){TextView v=label(title,12,true);v.setPadding(12,9,12,9);v.setGravity(Gravity.CENTER);v.setBackground(bg(libraryFolder.equals(folder)?0xffded6ff:Color.WHITE,14));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.rightMargin=7;v.setOnClickListener(x->{libraryFolder=folder;libraryFilter="all";showHome();});if(!folder.isEmpty())v.setOnLongClickListener(x->{new AlertDialog.Builder(this).setTitle(folder).setItems(new String[]{t("Rename folder","إعادة تسمية المجلد"),t("Delete folder","حذف المجلد")},(d,w)->{if(w==0){EditText input=new EditText(this);input.setText(folder);new AlertDialog.Builder(this).setTitle(t("Rename folder","إعادة تسمية المجلد")).setView(input).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Save","حفظ"),(a,b)->{store.renameFolder(folder,input.getText().toString());showHome();}).show();}else new AlertDialog.Builder(this).setMessage(t("Shortcuts in this folder will be moved to Unfiled. Continue?","سيتم نقل اختصارات هذا المجلد إلى بدون مجلد. هل تريد المتابعة؟")).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Delete","حذف"),(a,b)->{store.deleteFolder(folder);libraryFolder="";showHome();}).show();}).show();return true;});return v;}

    private void showLibraryTools(){String[] options={t("Export all shortcuts","تصدير كل الاختصارات"),t("Import shortcut JSON","استيراد اختصار JSON"),t("Create folder","إنشاء مجلد")};new AlertDialog.Builder(this).setTitle(t("Library tools","أدوات المكتبة")).setItems(options,(d,w)->{if(w==0)exportLibrary();else if(w==1)importShortcutDialog();else createFolderDialog();}).show();}
    private void exportLibrary(){try{JSONArray all=new JSONArray();for(Shortcut s:store.all()){JSONObject o=new JSONObject();o.put("format","hoda-shortcut-v1");o.put("name",s.name);o.put("icon",s.icon);o.put("color",s.color);o.put("folder",s.folder);o.put("favorite",s.favorite);o.put("actions",s.actions);all.put(o);}JSONObject backup=new JSONObject();backup.put("format","hoda-library-v1");backup.put("shortcuts",all);Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/json");send.putExtra(Intent.EXTRA_SUBJECT,"Hoda Scripts backup");send.putExtra(Intent.EXTRA_TEXT,backup.toString(2));startActivity(Intent.createChooser(send,t("Export library","تصدير المكتبة")));}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void importShortcutDialog(){EditText input=new EditText(this);input.setMinLines(5);input.setGravity(Gravity.TOP);input.setHint(t("Paste a Hoda shortcut or library JSON","الصق بيانات اختصار أو نسخة مكتبة Hoda بصيغة JSON"));new AlertDialog.Builder(this).setTitle(t("Import JSON","استيراد JSON")).setView(input).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Import","استيراد"),(d,w)->importJson(input.getText().toString())).show();}
    private void importJson(String raw){try{JSONObject root=new JSONObject(raw);String format=root.optString("format","");if(!format.isEmpty()&&!format.equals("hoda-shortcut-v1")&&!format.equals("hoda-library-v1"))throw new JSONException("Unsupported Hoda format");JSONArray arr=root.optJSONArray("shortcuts");if(arr==null){if(!format.isEmpty()&&!format.equals("hoda-shortcut-v1"))throw new JSONException("Missing shortcuts list");arr=new JSONArray();arr.put(root);}int imported=0;for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;String name=o.optString("name",t("Imported Shortcut","اختصار مستورد"));JSONArray actions=o.optJSONArray("actions");if(actions==null)actions=new JSONArray();Shortcut s=new Shortcut(0,name,o.optString("color","#EAE5FF"),o.optString("icon","⚡"),o.optString("folder",""),o.optBoolean("favorite",false),actions,System.currentTimeMillis());if(!s.folder.isEmpty())store.createFolder(s.folder);store.save(s);imported++;}Toast.makeText(this,t("Imported ","تم استيراد ")+imported+t(" shortcuts"," اختصارًا"),Toast.LENGTH_LONG).show();showHome();}catch(Exception e){new AlertDialog.Builder(this).setMessage(t("Invalid Hoda JSON: ","ملف JSON غير صالح: ")+e.getMessage()).setPositiveButton(t("OK","حسنًا"),null).show();}}

    private void showSortMenu(){String[] choices={t("Recently updated","الأحدث تعديلًا"),t("Name A–Z","الاسم أ–ي"),t("Name Z–A","الاسم ي–أ"),t("Most actions","الأكثر إجراءات")};new AlertDialog.Builder(this).setTitle(t("Sort shortcuts","ترتيب الاختصارات")).setItems(choices,(d,w)->{librarySort=new String[]{"recent","az","za","actions"}[w];renderLibraryResults();}).show();}
    private void createFolderDialog(){EditText input=new EditText(this);input.setSingleLine(true);input.setHint(t("Folder name","اسم المجلد"));new AlertDialog.Builder(this).setTitle(t("Create folder","إنشاء مجلد")).setView(input).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Create","إنشاء"),(d,w)->{String name=input.getText().toString().trim();if(!name.isEmpty()){store.createFolder(name);showHome();}}).show();}
    private void renderLibraryResults(){
        com.hoda.scripts.widget.HodaWidgetProvider.refresh(this);
        if(content==null)return;LinearLayout results=null;for(int i=0;i<content.getChildCount();i++){View v=content.getChildAt(i);if(v instanceof LinearLayout&&"library_results".equals(v.getTag())){results=(LinearLayout)v;break;}}
        if(results==null)return;results.removeAllViews();List<Shortcut> list=store.all();String q=libraryQuery.toLowerCase(Locale.ROOT);
        List<Shortcut> filtered=new ArrayList<>();for(Shortcut s:list){if("favorites".equals(libraryFilter)&&!s.favorite)continue;if("unfiled".equals(libraryFilter)&&!s.folder.isEmpty())continue;if(!libraryFolder.isEmpty()&&!libraryFolder.equals(s.folder))continue;if(!q.isEmpty()&&!s.name.toLowerCase(Locale.ROOT).contains(q)&&!s.folder.toLowerCase(Locale.ROOT).contains(q))continue;filtered.add(s);}
        if("az".equals(librarySort))Collections.sort(filtered,(a,b)->a.name.compareToIgnoreCase(b.name));else if("za".equals(librarySort))Collections.sort(filtered,(a,b)->b.name.compareToIgnoreCase(a.name));else if("actions".equals(librarySort))Collections.sort(filtered,(a,b)->Integer.compare(b.actions.length(),a.actions.length()));
        if(filtered.isEmpty()){LinearLayout empty=column();empty.setPadding(8,22,8,22);empty.addView(label(t("Nothing here yet","لا توجد اختصارات هنا بعد"),18,true));TextView hint=label(t("Create a shortcut, change the filter, or try another search.","أنشئ اختصارًا أو غيّر التصفية أو جرّب كلمة بحث أخرى."),13,false);hint.setTextColor(muted);empty.addView(hint);cardInto(results,empty);return;}
        for(Shortcut s:filtered){LinearLayout c=column();LinearLayout r=row();TextView icon=label(s.icon,25,true);icon.setGravity(Gravity.CENTER);icon.setBackground(bg(parseColor(s.color),16));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(54,54);ip.rightMargin=12;r.addView(icon,ip);
            LinearLayout info=column();info.addView(label(s.name,16,true));String meta=s.actions.length()+" "+t("actions","إجراءات")+(s.folder.isEmpty()?"":"  ·  📁 "+s.folder)+(s.favorite?"  ·  ★":"");TextView detail=label(meta,11,false);detail.setTextColor(muted);info.addView(detail);r.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            TextView fav=label(s.favorite?"★":"☆",22,true);fav.setTextColor(0xffe0a126);r.addView(fav);fav.setOnClickListener(v->{s.favorite=!s.favorite;store.save(s);renderLibraryResults();});TextView run=label("▶",18,true);run.setTextColor(purple);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-2,-2);rp.leftMargin=12;r.addView(run,rp);run.setOnClickListener(v->runShortcut(s));c.addView(r);
            c.setOnClickListener(v->editShortcut(s.id));c.setOnLongClickListener(v->{showShortcutMenu(s);return true;});cardInto(results,c);
        }
    }
    private void cardInto(LinearLayout parent,View v){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=9;v.setBackground(bg(Color.WHITE,20));v.setPadding(15,14,15,14);parent.addView(v,p);}
    private void showShortcutMenu(Shortcut s){String[] options={t("Open editor","فتح المحرر"),t("Run","تشغيل"),t("Duplicate","إنشاء نسخة"),t("Move to folder","نقل إلى مجلد"),t(s.favorite?"Remove favorite":"Add to favorites",s.favorite?"إزالة من المفضلة":"إضافة للمفضلة"),t("Share","مشاركة"),t("Delete","حذف"),t("Pin to Home screen","تثبيت على الشاشة الرئيسية")};new AlertDialog.Builder(this).setTitle(s.name).setItems(options,(d,w)->{switch(w){case 0:editShortcut(s.id);break;case 1:runShortcut(s);break;case 2:store.duplicate(s.id);showHome();break;case 3:moveShortcutDialog(s);break;case 4:s.favorite=!s.favorite;store.save(s);showHome();break;case 5:shareShortcut(s);break;case 6:new AlertDialog.Builder(this).setMessage(t("Delete this shortcut?","هل تريد حذف هذا الاختصار؟")).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Delete","حذف"),(x,y)->{store.delete(s.id);showHome();}).show();break;case 7:pinShortcut(s);break;}}).show();}
    private void pinShortcut(Shortcut shortcut){
        if(Build.VERSION.SDK_INT<26){Toast.makeText(this,t("Pinned shortcuts need Android 8 or later","تثبيت الاختصارات يحتاج أندرويد 8 أو أحدث"),Toast.LENGTH_LONG).show();return;}
        ShortcutManager manager=getSystemService(ShortcutManager.class);
        if(manager==null||!manager.isRequestPinShortcutSupported()){Toast.makeText(this,t("Your launcher does not support pinned shortcuts","مشغل الشاشة الرئيسية لا يدعم تثبيت الاختصارات"),Toast.LENGTH_LONG).show();return;}
        Intent launch=new Intent(this,MainActivity.class);launch.setAction("com.hoda.scripts.RUN_PINNED_SHORTCUT");launch.putExtra("hoda_shortcut_id",shortcut.id);launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        String shortLabel=shortcut.name.length()>25?shortcut.name.substring(0,25):shortcut.name;
        ShortcutInfo info=new ShortcutInfo.Builder(this,"hoda-"+shortcut.id).setShortLabel(shortLabel).setLongLabel(shortcut.name).setIcon(Icon.createWithResource(this,android.R.drawable.ic_media_play)).setIntent(launch).build();
        manager.requestPinShortcut(info,null);
    }
    private void moveShortcutDialog(Shortcut s){List<String> folders=store.folders();String[] names=new String[folders.size()+1];names[0]=t("No folder","بدون مجلد");for(int i=0;i<folders.size();i++)names[i+1]=folders.get(i);new AlertDialog.Builder(this).setTitle(t("Move shortcut","نقل الاختصار")).setItems(names,(d,w)->{s.folder=w==0?"":folders.get(w-1);store.save(s);showHome();}).show();}
    private void shareShortcut(Shortcut s){try{JSONObject data=new JSONObject();data.put("format","hoda-shortcut-v1");data.put("name",s.name);data.put("icon",s.icon);data.put("color",s.color);data.put("actions",s.actions);Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/json");send.putExtra(Intent.EXTRA_SUBJECT,s.name);send.putExtra(Intent.EXTRA_TEXT,data.toString(2));startActivity(Intent.createChooser(send,t("Share shortcut","مشاركة الاختصار")));}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}

    private int parseColor(String c){try{return Color.parseColor(c);}catch(Exception e){return 0xffeeeaff;}}
    private void newShortcut(){editShortcut(0);}

    /** Visual workflow editor. Actions are persisted as structured JSON objects. */
    private void editShortcut(long id){
        Shortcut s=id==0?new Shortcut(0,t("New Shortcut","اختصار جديد"),"#EAE5FF","⚡",new JSONArray(),0):store.get(id);
        if(s==null)return;
        final Shortcut item=s;
        LinearLayout editor=column(); editor.setPadding(4,4,4,4);
        EditText name=new EditText(this); name.setSingleLine(true); name.setText(item.name); name.setHint(t("Shortcut name","اسم الاختصار")); editor.addView(name);
        LinearLayout appearance=row(); final TextView[] iconPickRef=new TextView[1]; final TextView[] colorPickRef=new TextView[1];
        iconPickRef[0]=button(t("Icon: ","الأيقونة: ")+item.icon,()->chooseShortcutIcon(item,iconPickRef[0]));
        colorPickRef[0]=button(t("Color","اللون"),()->chooseShortcutColor(item,colorPickRef[0]));
        appearance.addView(iconPickRef[0],new LinearLayout.LayoutParams(0,-2,1)); appearance.addView(colorPickRef[0],new LinearLayout.LayoutParams(0,-2,1)); editor.addView(appearance);
        CheckBox favoriteBox=new CheckBox(this); favoriteBox.setText(t("Add to Favorites","إضافة إلى المفضلة")); favoriteBox.setChecked(item.favorite); editor.addView(favoriteBox);
        Spinner folderSpinner=new Spinner(this); List<String> editFolders=new ArrayList<>(); editFolders.add(t("No folder","بدون مجلد")); editFolders.addAll(store.folders());
        ArrayAdapter<String> folderAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,editFolders); folderSpinner.setAdapter(folderAdapter);
        int selectedFolder=editFolders.indexOf(item.folder.isEmpty()?editFolders.get(0):item.folder); folderSpinner.setSelection(Math.max(0,selectedFolder)); editor.addView(folderSpinner);
        TextView section=label(t("Workflow","تسلسل الإجراءات"),19,true); LinearLayout.LayoutParams secp=new LinearLayout.LayoutParams(-1,-2); secp.topMargin=16; editor.addView(section,secp);
        TextView help=label(t("Tap an action to edit it. Long-press and drag to reorder, or use its menu.","اضغط على الإجراء لتعديله. اضغط مطولًا واسحبه لتغيير ترتيبه، أو استخدم قائمته."),12,false); help.setTextColor(muted); editor.addView(help);
        LinearLayout list=column(); editor.addView(list);
        final Runnable[] refresh=new Runnable[1];
        refresh[0]=()->{
            list.removeAllViews();
            for(int i=0;i<item.actions.length();i++){
                JSONObject action=item.actions.optJSONObject(i); if(action==null)continue;
                final int index=i;
                LinearLayout block=row(); block.setPadding(12,10,8,10); block.setBackground(bg(action.optBoolean("enabled",true)?0xfff1eff8:0xffeeeeee,14));
                TextView number=label(String.valueOf(i+1),13,true); number.setTextColor(purple); number.setGravity(Gravity.CENTER); block.addView(number,new LinearLayout.LayoutParams(28,-2));
                LinearLayout detail=column(); TextView title=label(action.optString("title",action.optString("type","Action")),14,true); detail.addView(title);
                String val=action.optString("value",""); String sub=action.optString("category",t("Action","إجراء")); if(!val.isEmpty())sub+="  ·  "+val; TextView meta=label(sub,11,false); meta.setTextColor(muted); detail.addView(meta);
                block.addView(detail,new LinearLayout.LayoutParams(0,-2,1)); TextView dots=label("⋮",24,true); dots.setGravity(Gravity.CENTER); block.addView(dots,new LinearLayout.LayoutParams(34,42));
                LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.bottomMargin=7; list.addView(block,bp);
                block.setOnClickListener(v->editAction(item,index,refresh[0]));
                block.setOnLongClickListener(v->{ClipData data=ClipData.newPlainText("hoda-action-index",String.valueOf(index));View.DragShadowBuilder shadow=new View.DragShadowBuilder(block);if(Build.VERSION.SDK_INT>=24)block.startDragAndDrop(data,shadow,block,0);else block.startDrag(data,shadow,block,0);return true;});
                dots.setOnClickListener(v->{PopupMenu menu=new PopupMenu(this,dots);menu.getMenu().add(t("Edit","تعديل")).setOnMenuItemClickListener(m->{editAction(item,index,refresh[0]);return true;});menu.getMenu().add(t("Duplicate","نسخ")).setOnMenuItemClickListener(m->{try{item.actions.put(new JSONObject(item.actions.getJSONObject(index).toString()));refresh[0].run();}catch(Exception ignored){}return true;});menu.getMenu().add(t("Move up","تحريك لأعلى")).setOnMenuItemClickListener(m->{moveAction(item,index,index-1);refresh[0].run();return true;});menu.getMenu().add(t("Move down","تحريك لأسفل")).setOnMenuItemClickListener(m->{moveAction(item,index,index+1);refresh[0].run();return true;});menu.getMenu().add(t("Enable / Disable","تفعيل / تعطيل")).setOnMenuItemClickListener(m->{try{action.put("enabled",!action.optBoolean("enabled",true));}catch(JSONException ignored){}refresh[0].run();return true;});menu.getMenu().add(t("Delete","حذف")).setOnMenuItemClickListener(m->{item.actions.remove(index);refresh[0].run();return true;});menu.show();});
            }
            if(item.actions.length()==0){TextView empty=label(t("No actions yet. Add your first action below.","لا توجد إجراءات بعد. أضف أول إجراء من الأسفل."),13,false);empty.setTextColor(muted);empty.setPadding(8,18,8,18);list.addView(empty);}
        };
        list.setOnDragListener((v,event)->{
            if(event.getAction()==DragEvent.ACTION_DRAG_STARTED)return event.getClipDescription()!=null;
            if(event.getAction()==DragEvent.ACTION_DRAG_ENTERED){list.setBackground(bg(0xffeeeaff,12));return true;}
            if(event.getAction()==DragEvent.ACTION_DRAG_EXITED){list.setBackgroundColor(Color.TRANSPARENT);return true;}
            if(event.getAction()==DragEvent.ACTION_DROP){list.setBackgroundColor(Color.TRANSPARENT);try{int from=Integer.parseInt(event.getClipData().getItemAt(0).getText().toString());int to=list.getChildCount();for(int j=0;j<list.getChildCount();j++){View child=list.getChildAt(j);if(event.getY()<child.getY()+child.getHeight()/2f){to=j;break;}}if(to>=item.actions.length())to=item.actions.length()-1;moveAction(item,from,to);refresh[0].run();}catch(Exception ignored){}return true;}
            if(event.getAction()==DragEvent.ACTION_DRAG_ENDED){list.setBackgroundColor(Color.TRANSPARENT);return true;}return true;
        });
        refresh[0].run();
        TextView add=button(t("+ Add Action","+ إضافة إجراء"),()->chooseAction(item,refresh[0])); LinearLayout.LayoutParams addp=new LinearLayout.LayoutParams(-1,-2);addp.topMargin=8;editor.addView(add,addp);
        ScrollView scroll=new ScrollView(this);scroll.addView(editor);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(t("Shortcut Editor","محرر الاختصارات")).setView(scroll).setNegativeButton(t("Cancel","إلغاء"),null).setNeutralButton(t("Run","تشغيل"),null).setPositiveButton(t("Save","حفظ"),null).create();
        dialog.setOnShowListener(x->{dialog.getButton(-1).setOnClickListener(v->{item.name=name.getText().toString().trim();if(item.name.isEmpty())item.name=t("My Shortcut","اختصاري");item.favorite=favoriteBox.isChecked();int fi=folderSpinner.getSelectedItemPosition();item.folder=fi<=0?"":editFolders.get(fi);item.id=store.save(item);dialog.dismiss();showHome();});dialog.getButton(-3).setOnClickListener(v->{item.name=name.getText().toString().trim();runShortcut(item);});});
        dialog.show();
    }

    private void moveAction(Shortcut s,int from,int to){if(from<0||to<0||from>=s.actions.length()||to>=s.actions.length()||from==to)return;try{List<Object> ordered=new ArrayList<>();for(int i=0;i<s.actions.length();i++)ordered.add(s.actions.get(i));Object moving=ordered.remove(from);ordered.add(to,moving);JSONArray reordered=new JSONArray();for(Object action:ordered)reordered.put(action);s.actions=reordered;}catch(Exception ignored){}}

    private void chooseShortcutIcon(Shortcut s,TextView target){String[] icons={"⚡","⭐","❤️","🏠","☀️","🌙","🎵","📷","📁","💬","🌐","📝","🎮","🔔","🚀","🧰","📍","🔋","⏰","📧","🗂️","🧮","🎬","🛠️"};new AlertDialog.Builder(this).setTitle(t("Choose icon","اختر أيقونة")).setItems(icons,(d,w)->{s.icon=icons[w];target.setText(t("Icon: ","الأيقونة: ")+s.icon);}).show();}
    private void chooseShortcutColor(Shortcut s,TextView target){String[] names={t("Lavender","بنفسجي فاتح"),t("Blue","أزرق"),t("Green","أخضر"),t("Orange","برتقالي"),t("Pink","وردي"),t("Gray","رمادي")};String[] colors={"#EAE5FF","#DCEBFF","#DDF5E5","#FFE8D6","#FFE0EC","#E8E8ED"};new AlertDialog.Builder(this).setTitle(t("Choose color","اختر لونًا")).setItems(names,(d,w)->{s.color=colors[w];target.setText(names[w]);target.setBackground(bg(parseColor(s.color),18));}).show();}

    private void chooseAction(Shortcut s,Runnable refresh){
        List<ActionCatalog.Definition> defs=ActionCatalog.all(); final List<ActionCatalog.Definition> filtered=new ArrayList<>(defs);
        LinearLayout box=column(); EditText search=new EditText(this);search.setSingleLine(true);search.setHint(t("Search actions","ابحث عن إجراء"));box.addView(search);
        ListView results=new ListView(this);box.addView(results,new LinearLayout.LayoutParams(-1,520));
        final ArrayAdapter<String>[] adapter=new ArrayAdapter[1];
        Runnable update=()->{filtered.clear();String q=search.getText().toString().toLowerCase(Locale.ROOT);for(ActionCatalog.Definition d:defs)if((d.title+" "+d.category+" "+d.description).toLowerCase(Locale.ROOT).contains(q))filtered.add(d);String[] labels=new String[filtered.size()];for(int i=0;i<filtered.size();i++){ActionCatalog.Definition d=filtered.get(i);labels[i]=d.title+"\n"+d.category+" · "+d.description;}adapter[0]=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_2,android.R.id.text1,labels){@Override public View getView(int position,View convert,android.view.ViewGroup parent){LinearLayout item=column();TextView a=label(filtered.get(position).title,15,true);TextView b=label(filtered.get(position).category+" · "+filtered.get(position).description,11,false);b.setTextColor(muted);item.setPadding(14,10,14,10);item.addView(a);item.addView(b);return item;}};results.setAdapter(adapter[0]);};
        update.run();search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence x,int st,int c,int a){}public void onTextChanged(CharSequence x,int st,int before,int count){update.run();}public void afterTextChanged(Editable e){}});
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(t("Action Library","مكتبة الإجراءات")).setView(box).setNegativeButton(t("Close","إغلاق"),null).create();
        results.setOnItemClickListener((p,v,pos,l)->{ActionCatalog.Definition chosen=filtered.get(pos);dlg.dismiss();configureAction(s,chosen,refresh);});dlg.show();
    }

    private void configureAction(Shortcut s,ActionCatalog.Definition def,Runnable refresh){
        EditText value=new EditText(this);value.setText("");value.setHint(actionHint(def.id));
        if(def.id.equals("wait")||def.id.equals("brightness"))value.setInputType(2);
        if(def.id.equals("text")||def.id.equals("http_get")||def.id.equals("http_post")||def.id.equals("if")||def.id.equals("repeat")||def.id.equals("repeat_each")||def.id.equals("choose_menu")||def.id.equals("dictionary")) { value.setMinLines(3); value.setGravity(Gravity.TOP); }
        LinearLayout form=column();TextView description=label(def.description,13,false);description.setTextColor(muted);form.addView(description);form.addView(value);
        new AlertDialog.Builder(this).setTitle(t("Configure: ","إعداد: ")+def.title).setView(form).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Add Action","إضافة الإجراء"),(d,w)->{JSONObject a=new JSONObject();try{a.put("type",def.id);a.put("title",def.title);a.put("category",def.category);a.put("value",value.getText().toString());a.put("enabled",true);a.put("schema",1);}catch(JSONException ignored){}s.actions.put(a);refresh.run();}).show();
    }
    private String actionHint(String id){switch(id){case"wait":return "1000";case"url":return "https://example.com";case"http_get":return "{\"url\":\"https://httpbin.org/get\",\"retryCount\":2,\"retryDelayMs\":1000}";case"http_post":return "{\"url\":\"https://httpbin.org/post\",\"body\":\"{\\\"hello\\\":\\\"world\\\"}\",\"retryCount\":0}";case"if":return "{\"left\":\"$result\",\"operator\":\"equals\",\"right\":\"yes\",\"then\":[{\"type\":\"text\",\"value\":\"Matched\"}],\"else\":[]}";case"repeat":return "{\"count\":3,\"actions\":[{\"type\":\"notification\",\"value\":\"Loop ${repeat_index}\"}]}";case"repeat_each":return "{\"items\":[\"one\",\"two\"],\"actions\":[{\"type\":\"text\",\"value\":\"${item}\"}]}";case"choose_menu":return "{\"title\":\"Choose\",\"options\":[{\"title\":\"One\",\"actions\":[]},{\"title\":\"Two\",\"actions\":[]}]}";case"set_variable":return "name=value";case"get_variable":return "name";case"brightness":return "0-255";case"open_app":return t("Android package name, e.g. com.android.settings","اسم حزمة أندرويد، مثل com.android.settings");case"plugin_intent":return "{\"mode\":\"view\",\"uri\":\"https://example.com\"} or {\"mode\":\"share\",\"text\":\"Hello\"}";case"accessibility_global":return t("back, home, recents, notifications, quick_settings, power_dialog","back أو home أو recents أو notifications أو quick_settings أو power_dialog");case"accessibility_tap":return "{\"x\":300,\"y\":600}";case"notification":return t("Notification message","نص الإشعار");case"text":case"clipboard":return t("Text","النص");case"dictionary":return "{\"key\":\"value\"}";case"list_get":return "{\"variable\":\"result\",\"index\":0}";case"list_append":return "{\"variable\":\"result\",\"item\":\"new item\"}";case"file_read":return "text/plain";case"file_write":return "text/plain";default:return t("Enter a value","أدخل قيمة");}}

    private void editAction(Shortcut s,int index,Runnable refresh){JSONObject existing=s.actions.optJSONObject(index);if(existing==null)return;String type=existing.optString("type");ActionCatalog.Definition def=null;for(ActionCatalog.Definition d:ActionCatalog.all())if(d.id.equals(type)){def=d;break;}if(def==null){Toast.makeText(this,t("Unknown action type","نوع إجراء غير معروف"),Toast.LENGTH_SHORT).show();return;}
        final ActionCatalog.Definition selectedDef=def;
        if(type.equals("if")||type.equals("repeat")||type.equals("repeat_each")){
            editVisualBlock(existing,selectedDef,()->{refresh.run();});
            return;
        }
        EditText value=new EditText(this);value.setText(existing.optString("value",""));value.setHint(actionHint(type));if(type.equals("wait")||type.equals("brightness"))value.setInputType(2);if(type.equals("http_get")||type.equals("http_post")||type.equals("choose_menu")||type.equals("dictionary")){value.setMinLines(4);value.setGravity(Gravity.TOP);}LinearLayout form=column();TextView desc=label(selectedDef.description,13,false);desc.setTextColor(muted);form.addView(desc);form.addView(value);
        new AlertDialog.Builder(this).setTitle(t("Edit action","تعديل الإجراء")).setView(form).setNeutralButton(t("Delete","حذف"),(d,w)->{s.actions.remove(index);refresh.run();}).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Save","حفظ"),(d,w)->{try{existing.put("value",value.getText().toString());existing.put("title",selectedDef.title);existing.put("category",selectedDef.category);}catch(JSONException ignored){}refresh.run();}).show();
    }

    private void editVisualBlock(JSONObject action,ActionCatalog.Definition def,Runnable saved){
        JSONObject cfg;try{cfg=new JSONObject(action.optString("value","{}"));}catch(Exception e){cfg=new JSONObject();}
        final JSONObject config=cfg;LinearLayout form=column();form.setPadding(8,4,8,4);
        EditText left=null,right=null,operator=null,count=null,variable=null;
        if("if".equals(def.id)){
            left=field(config.optString("left","$result"),t("Left value / variable","القيمة أو المتغير الأول"));operator=field(config.optString("operator","equals"),"equals, not_equals, contains, greater_than...");right=field(config.optString("right","yes"),t("Compare with","القيمة الثانية"));
            addField(form,t("Condition","الشرط"),left);addField(form,t("Operator","المعامل"),operator);addField(form,t("Value","القيمة"),right);
            addBranchEditor(form,config,"then",t("IF TRUE — actions","إذا تحقق الشرط — الإجراءات"));addBranchEditor(form,config,"else",t("OTHERWISE — actions","وإلا — الإجراءات"));
        }else{
            if("repeat".equals(def.id)){count=field(String.valueOf(config.optInt("count",3)),t("Number of repetitions","عدد مرات التكرار"));count.setInputType(2);addField(form,t("Repeat count","عدد التكرارات"),count);}
            else {variable=field(config.optString("variable","result"),t("List variable name","اسم متغير القائمة"));addField(form,t("Repeat for each item in","كرر لكل عنصر في"),variable);}
            addBranchEditor(form,config,"actions",t("LOOP BODY — actions","داخل التكرار — الإجراءات"));
        }
        EditText fLeft=left,fOp=operator,fRight=right,fCount=count,fVariable=variable;
        new AlertDialog.Builder(this).setTitle(t("Visual block editor: ","محرر الكتل المرئي: ")+def.title).setView(form).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Save block","حفظ الكتلة"),(d,w)->{try{if("if".equals(def.id)){config.put("left",fLeft.getText().toString());config.put("operator",fOp.getText().toString().trim());config.put("right",fRight.getText().toString());}else if("repeat".equals(def.id))config.put("count",Math.max(0,Math.min(1000,Integer.parseInt(fCount.getText().toString().trim()))));else config.put("variable",fVariable.getText().toString().trim());action.put("value",config.toString());action.put("title",def.title);action.put("category",def.category);saved.run();}catch(Exception ex){Toast.makeText(this,t("Please check the block values","راجع قيم الكتلة"),Toast.LENGTH_LONG).show();}}).show();
    }
    private EditText field(String value,String hint){EditText e=new EditText(this);e.setText(value);e.setHint(hint);e.setSingleLine(true);return e;}
    private void addField(LinearLayout parent,String title,EditText input){TextView l=label(title,12,true);l.setPadding(0,7,0,0);parent.addView(l);parent.addView(input);}
    private void addBranchEditor(LinearLayout parent,JSONObject cfg,String key,String title){
        TextView heading=label(title,14,true);heading.setPadding(0,12,0,5);parent.addView(heading);LinearLayout list=column();parent.addView(list);final Runnable[] redraw=new Runnable[1];
        redraw[0]=()->{list.removeAllViews();JSONArray items=arrRef(cfg,key);for(int i=0;i<items.length();i++){JSONObject a=items.optJSONObject(i);if(a==null)continue;final int pos=i;LinearLayout line=row();TextView name=label((i+1)+". "+a.optString("title",a.optString("type")),13,true);line.addView(name,new LinearLayout.LayoutParams(0,-2,1));TextView up=label("↑",17,true);line.addView(up);up.setOnClickListener(v->{JSONArray aList=arrRef(cfg,key);if(pos>0){Object current=aList.opt(pos),previous=aList.opt(pos-1);try{aList.put(pos-1,current);aList.put(pos,previous);}catch(Exception ignored){}redraw[0].run();}});TextView down=label("↓",17,true);line.addView(down);down.setOnClickListener(v->{JSONArray aList=arrRef(cfg,key);if(pos<aList.length()-1){Object current=aList.opt(pos),next=aList.opt(pos+1);try{aList.put(pos+1,current);aList.put(pos,next);}catch(Exception ignored){}redraw[0].run();}});TextView edit=label("✎",18,true);line.addView(edit);edit.setOnClickListener(v->editNestedAction(arrRef(cfg,key),pos,redraw[0]));TextView remove=label(" × ",18,true);line.addView(remove);remove.setOnClickListener(v->{arrRef(cfg,key).remove(pos);redraw[0].run();});list.addView(line);View divider=new View(this);divider.setBackgroundColor(0xffeeeeF3);list.addView(divider,new LinearLayout.LayoutParams(-1,1));}list.addView(button(t("+ Add action","+ إضافة إجراء"),()->chooseNestedAction(cfg,key,redraw[0])));};redraw[0].run();
    }
    private JSONArray arrRef(JSONObject cfg,String key){JSONArray a=cfg.optJSONArray(key);if(a==null){a=new JSONArray();try{cfg.put(key,a);}catch(Exception ignored){}}return a;}
    private void chooseNestedAction(JSONObject cfg,String key,Runnable refresh){List<ActionCatalog.Definition> defs=ActionCatalog.all();String[] names=new String[defs.size()];for(int i=0;i<defs.size();i++)names[i]=defs.get(i).title;new AlertDialog.Builder(this).setTitle(t("Add action to block","إضافة إجراء داخل الكتلة")).setItems(names,(d,w)->{ActionCatalog.Definition def=defs.get(w);EditText value=field("",actionHint(def.id));if(def.id.equals("if")||def.id.equals("repeat")||def.id.equals("repeat_each")){JSONObject nested=new JSONObject();try{nested.put("type",def.id);nested.put("title",def.title);nested.put("value",def.id.equals("if")?"{\"left\":\"$result\",\"operator\":\"equals\",\"right\":\"yes\",\"then\":[],\"else\":[]}":def.id.equals("repeat")?"{\"count\":3,\"actions\":[]}":"{\"variable\":\"result\",\"actions\":[]}");arrRef(cfg,key).put(nested);}catch(Exception ignored){}refresh.run();}else new AlertDialog.Builder(this).setTitle(def.title).setView(value).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Add","إضافة"),(x,y)->{JSONObject a=new JSONObject();try{a.put("type",def.id);a.put("title",def.title);a.put("category",def.category);a.put("value",value.getText().toString());a.put("enabled",true);arrRef(cfg,key).put(a);}catch(Exception ignored){}refresh.run();}).show();}).show();}
    private void editNestedAction(JSONArray actions,int index,Runnable refresh){JSONObject a=actions.optJSONObject(index);if(a==null)return;String type=a.optString("type");if(type.equals("if")||type.equals("repeat")||type.equals("repeat_each")){ActionCatalog.Definition def=null;for(ActionCatalog.Definition candidate:ActionCatalog.all())if(candidate.id.equals(type)){def=candidate;break;}if(def!=null){editVisualBlock(a,def,refresh);return;}}EditText value=field(a.optString("value",""),actionHint(type));new AlertDialog.Builder(this).setTitle(t("Edit nested action","تعديل الإجراء الداخلي")).setView(value).setNegativeButton(t("Cancel","إلغاء"),null).setNeutralButton(t("Delete","حذف"),(d,w)->{actions.remove(index);refresh.run();}).setPositiveButton(t("Save","حفظ"),(d,w)->{try{a.put("value",value.getText().toString());}catch(Exception ignored){}refresh.run();}).show();}

    private void runShortcut(Shortcut s){
        if(activeEngine!=null) activeEngine.cancel();
        ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(Math.max(1,s.actions.length()));
        TextView status=label(t("Preparing shortcut…","جارٍ تجهيز الاختصار…"),13,false);
        LinearLayout box=column();box.setPadding(18,8,18,8);box.addView(status);box.addView(progress);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(s.name).setView(box)
            .setNegativeButton(t("Stop","إيقاف"),(d,w)->{if(activeEngine!=null)activeEngine.cancel();})
            .setNeutralButton(t("Run in background","تشغيل في الخلفية"),(d,w)->startShortcutInBackground(s)).create();
        dialog.setCancelable(false);
        activeEngine=new com.hoda.scripts.engine.ShortcutExecutionEngine(this,s,new com.hoda.scripts.engine.ShortcutExecutionEngine.Listener(){
            @Override public void onStarted(String name){dialog.show();}
            @Override public void onProgress(int completed,int total,String title){progress.setMax(Math.max(1,total));progress.setProgress(completed);status.setText(title+"  ·  "+completed+" / "+total);}
            @Override public void onFinished(Map<String,Object> vars){if(dialog.isShowing())dialog.dismiss();activeEngine=null;Object result=vars.get("result");String message=t("Shortcut completed","اكتمل الاختصار");if(result!=null)message+="\n"+String.valueOf(result);com.hoda.scripts.data.RunHistoryStore.add(MainActivity.this,s.name,true,message);new AlertDialog.Builder(MainActivity.this).setTitle(s.name).setMessage(message).setPositiveButton(t("Done","تم"),null).show();}
            @Override public void onError(String actionTitle,String message){if(dialog.isShowing())dialog.dismiss();activeEngine=null;com.hoda.scripts.data.RunHistoryStore.add(MainActivity.this,s.name,false,actionTitle+": "+message);new AlertDialog.Builder(MainActivity.this).setTitle(t("Shortcut failed","فشل الاختصار")).setMessage(actionTitle+"\n"+message).setPositiveButton(t("OK","حسنًا"),null).show();}
        });
        activeEngine.start();
    }
    private void startShortcutInBackground(Shortcut shortcut){
        if(activeEngine!=null){activeEngine.cancel();activeEngine=null;}
        Intent intent=new Intent(this,com.hoda.scripts.engine.AutomationService.class);
        intent.setAction(com.hoda.scripts.engine.AutomationService.ACTION_RUN_SHORTCUT);
        intent.putExtra(com.hoda.scripts.engine.AutomationService.EXTRA_SHORTCUT_NAME,shortcut.name);
        intent.putExtra(com.hoda.scripts.engine.AutomationService.EXTRA_SHORTCUT_ACTIONS,shortcut.actions.toString());
        try{if(Build.VERSION.SDK_INT>=26)startForegroundService(intent);else startService(intent);Toast.makeText(this,t("Background run started. Check the persistent notification.","بدأ التشغيل في الخلفية. تابع الإشعار الدائم."),Toast.LENGTH_LONG).show();}
        catch(Exception e){Toast.makeText(this,t("Could not start background run: ","تعذر بدء التشغيل في الخلفية: ")+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void showCustom(){ page="custom"; showRegions(); }

    private void showRegions(){
        page="regions";base(t("Screen Regions","مناطق الشاشة"));
        LinearLayout head=row();
        TextView intro=label(t("Each region keeps its own real gesture timings and speed settings.","كل منطقة لها إعدادات حقيقية مستقلة للمدة والسرعة والتنفيذ."),13,false);
        intro.setTextColor(muted);head.addView(intro,new LinearLayout.LayoutParams(0,-2,1));
        head.addView(button(t("+ New region","+ منطقة جديدة"),this::startRegionSelection));content.addView(head);
        java.util.List<ScreenRegion> regions=regionStore.all();
        if(regions.isEmpty()){TextView empty=label(t("No regions yet. Create one and drag over the screen.","لا توجد مناطق بعد. أنشئ منطقة واسحب على الشاشة لتحديدها."),14,false);empty.setTextColor(muted);card(empty);return;}
        for(ScreenRegion r:regions){
            LinearLayout item=column();LinearLayout titleRow=row();
            TextView name=label(r.name,17,true);name.setOnClickListener(v->runRegion(r));name.setOnLongClickListener(v->{editRegion(r);return true;});titleRow.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            TextView tag=label("▣",20,true);tag.setTextColor(purple);titleRow.addView(tag);item.addView(titleRow);
            TextView meta=label("X "+r.x+"  Y "+r.y+"  ·  "+r.width+" × "+r.height,t("منطقة الشاشة","Screen region"),13,false);meta.setTextColor(muted);item.addView(meta);
            TextView values=label(t(r.actionMode+" · Tap "+r.tapDurationMs+"ms · Hold "+r.holdDurationMs+"ms · Swipe "+r.swipeDurationMs+"ms · Speed "+r.swipeSpeedPxPerSec,
                "الوضع "+r.actionMode+" · لمس "+r.tapDurationMs+"ms · استمرار "+r.holdDurationMs+"ms · سحب "+r.swipeDurationMs+"ms · سرعة "+r.swipeSpeedPxPerSec),12,false);
            values.setTextColor(muted);item.addView(values);
            LinearLayout actions=row();
            actions.addView(button(t("Open","فتح"),()->editRegion(r)),new LinearLayout.LayoutParams(0,-2,1));
            actions.addView(button(t("Run","تشغيل"),()->runRegion(r)));
            actions.addView(button(t("Delete","حذف"),()->new AlertDialog.Builder(this).setMessage(t("Delete this region?","حذف هذه المنطقة؟")).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Delete","حذف"),(d,w)->{regionStore.delete(r.id);showRegions();}).show()));
            item.addView(actions);card(item);
        }
    }

    private void startRegionSelection(){startActivityForResult(new Intent(this,RegionSelectorActivity.class),REQ_REGION_SELECT);}

    private void createRegionFromSelection(int x,int y,int w,int h){
        EditText name=new EditText(this);name.setSingleLine(true);name.setHint(t("Region name","اسم المنطقة"));
        new AlertDialog.Builder(this).setTitle(t("Name this region","سمِّ المنطقة")).setView(name)
            .setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Save","حفظ"),(d,which)->{
                String n=name.getText().toString().trim();if(n.isEmpty())n=t("New region","منطقة جديدة");
                ScreenRegion r=new ScreenRegion(0,n,"#EAE5FF",x,y,w,h,80,0,500,200,0,1,0,"tap",80,500,300,System.currentTimeMillis());
                regionStore.save(r);editRegion(r);
            }).show();
    }

    private EditText numberField(String value,String hint){
        EditText e=new EditText(this);e.setSingleLine(true);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);e.setText(value);e.setHint(hint);return e;
    }
    private Spinner modeSpinner(String current){
        Spinner s=new Spinner(this);String[] vals={t("Tap","لمس"),t("Hold","ضغط مع الاستمرار"),t("Swipe","سحب")};
        String[] keys={"tap","hold","swipe"};ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,vals);s.setAdapter(a);
        for(int i=0;i<keys.length;i++)if(keys[i].equals(current))s.setSelection(i);return s;
    }
    private long fieldMs(EditText e,long fallback){return Math.max(0,Math.min(1000,parseLongSafe(e.getText().toString(),fallback)));}
    private void editRegion(ScreenRegion r){
        LinearLayout box=column();
        EditText name=new EditText(this);name.setSingleLine(true);name.setText(r.name);box.addView(label(t("Region name","اسم المنطقة"),13,true));box.addView(name);
        TextView coords=label("X="+r.x+"  Y="+r.y+"  ·  "+r.width+" × "+r.height,12,false);coords.setTextColor(muted);box.addView(coords);
        Spinner mode=modeSpinner(r.actionMode);box.addView(label(t("Region action","وظيفة المنطقة"),13,true));box.addView(mode);

        EditText tap=numberField(String.valueOf(r.tapDurationMs),t("0–1000 ms","0–1000 مللي ثانية"));box.addView(label(t("Tap duration — actual touch stroke","مدة اللمس — مدة اللمسة الفعلية"),13,true));box.addView(tap);
        EditText tapSpeed=numberField(String.valueOf(r.tapSpeedMs),t("0–1000 touches/s","0–1000 لمسة/ثانية"));box.addView(label(t("Touch speed","سرعة اللمس (لمسة/ثانية)"),13,true));box.addView(tapSpeed);
        EditText hold=numberField(String.valueOf(r.holdDurationMs),t("0–1000 ms","0–1000 مللي ثانية"));box.addView(label(t("Hold duration","مدة النقر مع الاستمرار"),13,true));box.addView(hold);
        EditText swipe=numberField(String.valueOf(r.swipeDurationMs),t("0–1000 ms","0–1000 مللي ثانية"));box.addView(label(t("Swipe duration","مدة السحب"),13,true));box.addView(swipe);
        EditText swipeSpeed=numberField(String.valueOf(r.swipeSpeedPxPerSec),t("0 = use duration","0 = استخدم مدة السحب"));box.addView(label(t("Swipe speed (px/s)","سرعة السحب (بكسل/ثانية)"),13,true));box.addView(swipeSpeed);
        EditText repeat=numberField(String.valueOf(r.repetitions),t("1–100","1–100"));box.addView(label(t("Repetitions","عدد التكرار"),13,true));box.addView(repeat);
        EditText interval=numberField(String.valueOf(r.intervalMs),t("0–1000 ms","0–1000 مللي ثانية"));box.addView(label(t("Extra interval","الفاصل الإضافي"),13,true));box.addView(interval);

        box.addView(label(t("Icon settings","إعدادات الأيقونة"),16,true));
        EditText iconTap=numberField(String.valueOf(r.iconTapDurationMs),t("0–1000 ms","0–1000 مللي ثانية"));box.addView(label(t("Icon tap duration","مدة النقر على الأيقونة"),13,true));box.addView(iconTap);
        EditText iconLong=numberField(String.valueOf(r.iconLongPressDurationMs),t("1–1000 ms","1–1000 مللي ثانية"));box.addView(label(t("Icon long-press duration","مدة الضغط المطول على الأيقونة"),13,true));box.addView(iconLong);
        EditText iconDouble=numberField(String.valueOf(r.iconDoubleTapDurationMs),t("1–1000 ms","1–1000 مللي ثانية"));box.addView(label(t("Icon double-tap window","مدة الضغطتين للأيقونة"),13,true));box.addView(iconDouble);

        TextView note=label(t("Touch speed is a rate (touches/second), not milliseconds. If touch speed is 0, the saved touch duration and interval are used. If touch speed is greater than 0, the engine uses that rate to calculate the time between touch starts. Swipe speed is px/second; if it is 0, swipe duration is used. Duration 0 is stored exactly, but Android gesture strokes require at least 1ms at execution time.",
            "سرعة اللمس هي معدل (لمسة/ثانية) وليست مللي ثانية. إذا كانت سرعة اللمس 0 تُستخدم مدة اللمس والفاصل المحفوظان. وإذا كانت أكبر من 0 يحسب المحرك الزمن بين بدايات اللمسات من المعدل. سرعة السحب بكسل/ثانية؛ وإذا كانت 0 تُستخدم مدة السحب. مدة 0 تُحفظ كما هي، لكن Android يتطلب 1ms على الأقل عند تنفيذ Gesture فعلي."),11,false);
        note.setTextColor(muted);box.addView(note);

        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(r.name).setView(box)
            .setNegativeButton(t("Cancel","إلغاء"),null).setNeutralButton(t("Run","تشغيل"),null).setPositiveButton(t("Save","حفظ"),null).create();
        dlg.setOnShowListener(v->{
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x->{
                r.name=name.getText().toString().trim();if(r.name.isEmpty())r.name=t("Region","منطقة");
                String[] keys={"tap","hold","swipe"};r.actionMode=keys[mode.getSelectedItemPosition()];
                r.tapDurationMs=fieldMs(tap,80);r.tapSpeedMs=Math.max(0,Math.min(1000,parseLongSafe(tapSpeed.getText().toString(),0)));r.holdDurationMs=fieldMs(hold,500);r.swipeDurationMs=fieldMs(swipe,200);
                r.swipeSpeedPxPerSec=Math.max(0,Math.min(100000,parseLongSafe(swipeSpeed.getText().toString(),0)));
                r.repetitions=(int)Math.max(1,Math.min(100,parseLongSafe(repeat.getText().toString(),1)));
                r.intervalMs=fieldMs(interval,0);r.iconTapDurationMs=fieldMs(iconTap,80);
                r.iconLongPressDurationMs=Math.max(1,Math.min(1000,parseLongSafe(iconLong.getText().toString(),500)));
                r.iconDoubleTapDurationMs=Math.max(1,Math.min(1000,parseLongSafe(iconDouble.getText().toString(),300)));
                regionStore.save(r);dlg.dismiss();showRegions();
            });
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(x->{regionStore.save(r);runRegion(r);});
        });dlg.show();
    }
    private long parseLongSafe(String s,long fallback){try{return Long.parseLong(s.trim());}catch(Exception e){return fallback;}}

    private void runRegion(ScreenRegion r){
        if(!com.hoda.scripts.accessibility.HodaAccessibilityService.isConnected()){
            new AlertDialog.Builder(this).setTitle(t("Accessibility required","يلزم Accessibility"))
                .setMessage(t("Enable Hoda Scripts Accessibility first. It is required to send the real screen gesture.","فعّل خدمة Accessibility الخاصة بـ Hoda Scripts أولًا. هي المطلوبة لإرسال حركة الشاشة الفعلية."))
                .setPositiveButton(t("Open settings","فتح الإعدادات"),(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                .setNegativeButton(t("Cancel","إلغاء"),null).show();return;
        }
        com.hoda.scripts.accessibility.HodaAccessibilityService.runRegion(r,r.centerX(),r.centerY(),
            ()->runOnUiThread(()->Toast.makeText(this,t("Region executed","تم تشغيل المنطقة"),Toast.LENGTH_SHORT).show()));
    }
    private void showRegionBubble(ScreenRegion r){
        if(!com.hoda.scripts.accessibility.HodaAccessibilityService.isConnected()){
            new AlertDialog.Builder(this).setTitle(t("Accessibility required","يلزم Accessibility"))
                .setMessage(t("Enable Hoda Scripts Accessibility first.","فعّل خدمة Accessibility الخاصة بـ Hoda Scripts أولًا."))
                .setPositiveButton(t("Open settings","فتح الإعدادات"),(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                .setNegativeButton(t("Cancel","إلغاء"),null).show();return;
        }
        if(!com.hoda.scripts.accessibility.HodaAccessibilityService.showRegionBubble(r))
            Toast.makeText(this,t("Could not show the floating control","تعذر إظهار الكرة العائمة"),Toast.LENGTH_LONG).show();
    }

private void showAutomation(){
        page="automation";base(t("Automation","الأتمتة"));
        card(label(t("Automation center","مركز الأتمتة"),18,true));
        TextView d=label(t("Create rules that launch one of your shortcuts when a schedule or supported device event occurs. Android may delay or restrict background launches.","أنشئ قواعد لتشغيل اختصاراتك عند موعد محدد أو وقوع حدث مدعوم في الهاتف. قد يؤخر أندرويد التشغيل في الخلفية أو يقيّده."),14,false);d.setTextColor(muted);card(d);
        content.addView(button(t("+ New automation rule","+ قاعدة أتمتة جديدة"),this::createAutomationRule));
        TextView heading=label(t("Your automation rules","قواعد الأتمتة الخاصة بك"),19,true);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=14;content.addView(heading,hp);
        java.util.List<org.json.JSONObject> rules=com.hoda.scripts.automation.AutomationRuleStore.all(this);
        if(rules.isEmpty()){TextView empty=label(t("No rules yet. Add a rule to get started.","لا توجد قواعد بعد. أضف قاعدة للبدء."),13,false);empty.setTextColor(muted);card(empty);}
        for(org.json.JSONObject rule:rules){
            LinearLayout item=column();String trigger=rule.optString("trigger");String title=triggerLabel(trigger);long sid=rule.optLong("shortcut_id");Shortcut shortcut=store.get(sid);String detail=(shortcut==null?t("Missing shortcut","اختصار غير موجود"):shortcut.name);
            if("daily_time".equals(trigger))detail+=" · "+String.format(java.util.Locale.getDefault(),"%02d:%02d",rule.optInt("hour"),rule.optInt("minute"));
            TextView name=label(title,16,true);item.addView(name);TextView sub=label(detail,13,false);sub.setTextColor(muted);item.addView(sub);
            LinearLayout actions=row();TextView state=label(rule.optBoolean("enabled",true)?t("Enabled","مفعّلة"):t("Disabled","متوقفة"),12,true);state.setTextColor(rule.optBoolean("enabled",true)?0xff238636:muted);actions.addView(state,new LinearLayout.LayoutParams(0,-2,1));
            actions.addView(button(rule.optBoolean("enabled",true)?t("Disable","إيقاف"):t("Enable","تفعيل"),()->{try{rule.put("enabled",!rule.optBoolean("enabled",true));com.hoda.scripts.automation.AutomationRuleStore.put(this,rule);if(rule.optBoolean("enabled",true))com.hoda.scripts.automation.AutomationScheduler.schedule(this,rule);else com.hoda.scripts.automation.AutomationScheduler.cancel(this,rule.optString("id"));showAutomation();}catch(org.json.JSONException ignored){}}));
            actions.addView(button(t("Delete","حذف"),()->{com.hoda.scripts.automation.AutomationScheduler.cancel(this,rule.optString("id"));com.hoda.scripts.automation.AutomationRuleStore.remove(this,rule.optString("id"));showAutomation();}));item.addView(actions);card(item);
        }
        TextView supported=label(t("Triggers: daily time, power connected/disconnected, battery low/okay, Wi-Fi connected/disconnected, and Bluetooth on/off.","المحفزات: موعد يومي، توصيل/فصل الشاحن، انخفاض/تحسن البطارية، الاتصال/فصل Wi-Fi، وتشغيل/إيقاف Bluetooth."),12,false);supported.setTextColor(muted);card(supported);
    }
    private String triggerLabel(String key){if("daily_time".equals(key))return t("Daily schedule","موعد يومي");if("power_connected".equals(key))return t("Power connected","تم توصيل الشاحن");if("power_disconnected".equals(key))return t("Power disconnected","تم فصل الشاحن");if("battery_low".equals(key))return t("Battery low","البطارية منخفضة");if("battery_okay".equals(key))return t("Battery okay","البطارية عادت للوضع الطبيعي");if("wifi_connected".equals(key))return t("Wi-Fi connected","تم الاتصال بشبكة Wi-Fi");if("wifi_disconnected".equals(key))return t("Wi-Fi disconnected","تم فصل Wi-Fi");if("bluetooth_on".equals(key))return t("Bluetooth turned on","تم تشغيل Bluetooth");return t("Bluetooth turned off","تم إيقاف Bluetooth");}
    private void createAutomationRule(){
        java.util.List<Shortcut> shortcuts=store.all();if(shortcuts.isEmpty()){new AlertDialog.Builder(this).setMessage(t("Create a shortcut first.","أنشئ اختصارًا أولًا.")).setPositiveButton(t("OK","حسنًا"),null).show();return;}
        String[] names=new String[shortcuts.size()];for(int i=0;i<shortcuts.size();i++)names[i]=shortcuts.get(i).name;
        String[] triggers={t("Daily time","موعد يومي"),t("Power connected","توصيل الشاحن"),t("Power disconnected","فصل الشاحن"),t("Battery low","البطارية منخفضة"),t("Battery okay","البطارية طبيعية"),t("Wi-Fi connected","الاتصال بـ Wi-Fi"),t("Wi-Fi disconnected","فصل Wi-Fi"),t("Bluetooth on","تشغيل Bluetooth"),t("Bluetooth off","إيقاف Bluetooth")};
        String[] keys={"daily_time","power_connected","power_disconnected","battery_low","battery_okay","wifi_connected","wifi_disconnected","bluetooth_on","bluetooth_off"};
        Spinner shortcutSpinner=new Spinner(this);shortcutSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));Spinner triggerSpinner=new Spinner(this);triggerSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,triggers));LinearLayout box=column();box.addView(label(t("Run this shortcut","تشغيل هذا الاختصار"),13,true));box.addView(shortcutSpinner);box.addView(label(t("When this happens","عند حدوث"),13,true));box.addView(triggerSpinner);
        new AlertDialog.Builder(this).setTitle(t("New automation","أتمتة جديدة")).setView(box).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Next","التالي"),(dialog,which)->{
            int si=shortcutSpinner.getSelectedItemPosition(),ti=triggerSpinner.getSelectedItemPosition();Shortcut selected=shortcuts.get(si);
            if("daily_time".equals(keys[ti])){java.util.Calendar now=java.util.Calendar.getInstance();new TimePickerDialog(this,(view,hour,minute)->saveAutomationRule(selected,keys[ti],hour,minute),now.get(java.util.Calendar.HOUR_OF_DAY),now.get(java.util.Calendar.MINUTE),true).show();}
            else saveAutomationRule(selected,keys[ti],0,0);
        }).show();
    }
    private void saveAutomationRule(Shortcut shortcut,String trigger,int hour,int minute){try{org.json.JSONObject rule=new org.json.JSONObject();String id=java.util.UUID.randomUUID().toString();rule.put("id",id);rule.put("shortcut_id",shortcut.id);rule.put("trigger",trigger);rule.put("hour",hour);rule.put("minute",minute);rule.put("enabled",true);com.hoda.scripts.automation.AutomationRuleStore.put(this,rule);com.hoda.scripts.automation.AutomationScheduler.schedule(this,rule);Toast.makeText(this,t("Automation rule saved","تم حفظ قاعدة الأتمتة"),Toast.LENGTH_SHORT).show();showAutomation();}catch(org.json.JSONException ignored){}}

    private void showGallery(){
        page="gallery";base(t("Gallery","المعرض"));
        TextView intro=label(t("Starter shortcuts you can add to your library and customize.","اختصارات بداية يمكنك إضافتها إلى مكتبتك وتخصيصها."),13,false);intro.setTextColor(muted);card(intro);
        galleryTemplate("Morning Setup","☀️",t("A simple morning notification.","إشعار صباحي بسيط."),"notification",t("Good morning! Start your day.","صباح الخير! ابدأ يومك."));
        galleryTemplate("Quick Note","📝",t("Copy a starter note to your clipboard.","انسخ قالب ملاحظة إلى الحافظة."),"clipboard",t("My quick note","ملاحظتي السريعة"));
        galleryTemplate("Open Website","🌐",t("Open a website in your browser.","افتح موقعًا في المتصفح."),"url","https://www.example.com");
    }
    private void galleryTemplate(String name,String icon,String description,String type,String value){LinearLayout c=column();LinearLayout r=row();TextView badge=label(icon,25,true);badge.setGravity(Gravity.CENTER);badge.setBackground(bg(0xffeeeaff,15));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(48,48);bp.rightMargin=12;r.addView(badge,bp);LinearLayout info=column();info.addView(label(name,17,true));TextView desc=label(description,12,false);desc.setTextColor(muted);info.addView(desc);r.addView(info,new LinearLayout.LayoutParams(0,-2,1));c.addView(r);TextView add=button(t("Add to My Shortcuts","إضافة إلى اختصاراتي"),()->{JSONArray actions=new JSONArray();JSONObject a=new JSONObject();try{a.put("type",type);a.put("title",type.equals("url")?"Open URL":type.equals("clipboard")?"Copy to Clipboard":"Show Notification");a.put("value",value);actions.put(a);}catch(JSONException ignored){}Shortcut s=new Shortcut(0,name,"#EAE5FF",icon,actions,System.currentTimeMillis());store.save(s);Toast.makeText(this,t("Added to your library","تمت الإضافة إلى مكتبتك"),Toast.LENGTH_SHORT).show();page="shortcuts";showHome();});LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);ap.topMargin=12;c.addView(add,ap);card(c);}

    private void showSettings(){
        page="settings";base(t("Settings","الإعدادات"));
        TextView lang=label(t("Language","اللغة")+"   ·   "+(arabic?"العربية":"English"),17,true);card(lang);
        content.addView(button(t("Switch language","تغيير اللغة"),()->{arabic=!arabic;getPreferences(0).edit().putBoolean("ar",arabic).apply();showSettings();}));
        TextView assistTitle=label(t("Voice and run history","الأوامر الصوتية وسجل التشغيل"),19,true);LinearLayout.LayoutParams assistParams=new LinearLayout.LayoutParams(-1,-2);assistParams.topMargin=18;content.addView(assistTitle,assistParams);
        TextView voiceInfo=label(t("Use your device speech recognizer to say the name of a saved shortcut. Recognition is started only when you tap the button.","استخدم خدمة التعرف على الكلام في هاتفك لنطق اسم اختصار محفوظ. لن يبدأ الاستماع إلا عندما تضغط الزر."),13,false);voiceInfo.setTextColor(muted);card(voiceInfo);
        content.addView(button(t("Run a shortcut by voice","تشغيل اختصار بالصوت"),this::startVoiceShortcut));
        content.addView(button(t("View execution history","عرض سجل التشغيل"),this::showRunHistory));
        TextView bgTitle=label(t("Background automation","تشغيل الأتمتة في الخلفية"),19,true);card(bgTitle);
        boolean ignoring=false; PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE); if(Build.VERSION.SDK_INT>=23&&pm!=null)ignoring=pm.isIgnoringBatteryOptimizations(getPackageName());
        TextView status=label(t("Battery optimization: ","تحسين البطارية: ")+(ignoring?t("Exempted","مستثنى"):t("Enabled by system","مفعّل من النظام")),14,true);status.setTextColor(ignoring?0xff238636:0xffb7791f);card(status);
        TextView explain=label(t("Enable the visible background engine, then allow Hoda Scripts in Android battery settings. Android still controls background limits; this cannot force every task to run forever.","فعّل محرك الخلفية الظاهر، ثم اسمح لـ Hoda Scripts بالعمل دون تقييد من إعدادات بطارية أندرويد. يظل النظام هو المتحكم في قيود الخلفية ولا يمكن ضمان تشغيل كل مهمة للأبد."),13,false);explain.setTextColor(muted);card(explain);
        content.addView(button(t("Enable background engine","تفعيل محرك الخلفية"),this::enableBackgroundEngine));
        content.addView(button(t("Stop background engine","إيقاف محرك الخلفية"),()->{stopService(new Intent(this,com.hoda.scripts.engine.AutomationService.class));Toast.makeText(this,t("Background engine stopped","تم إيقاف محرك الخلفية"),Toast.LENGTH_SHORT).show();}));
        content.addView(button(t("Open battery optimization settings","فتح إعدادات تحسين البطارية"),()->{try{startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}catch(Exception e){openAppDetails();}}));
        content.addView(button(t("Open Hoda Scripts app settings","فتح إعدادات التطبيق"),this::openAppDetails));
        TextView accessTitle=label(t("Optional Accessibility integration","تكامل Accessibility الاختياري"),19,true);LinearLayout.LayoutParams atp=new LinearLayout.LayoutParams(-1,-2);atp.topMargin=22;content.addView(accessTitle,atp);
        boolean accessibilityEnabled=isHodaAccessibilityEnabled();
        TextView accessStatus=label(t("Accessibility status: ","حالة Accessibility: ")+(accessibilityEnabled?t("Enabled in Android settings","مفعّلة من إعدادات أندرويد"):t("Not enabled","غير مفعّلة")),14,true);accessStatus.setTextColor(accessibilityEnabled?0xff238636:0xffb7791f);card(accessStatus);
        TextView accessInfo=label(t("This optional service can perform selected system navigation actions and screen taps only after you manually enable it in Android Accessibility settings. Hoda does not read window contents, capture passwords, or collect accessibility events. You can turn it off at any time in system settings.","الخدمة الاختيارية دي تقدر تنفذ بعض أوامر التنقل ولمسات الشاشة بعد ما تفعّلها بنفسك من إعدادات Accessibility. التطبيق لا يقرأ محتوى النوافذ ولا يلتقط كلمات المرور ولا يجمع أحداث إمكانية الوصول. تقدر توقفها في أي وقت من إعدادات النظام."),13,false);accessInfo.setTextColor(muted);card(accessInfo);
        content.addView(button(t("Open Accessibility settings","فتح إعدادات Accessibility"),()->{try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception e){openAppDetails();}}));
        content.addView(button(t("Browse installed apps","استعراض التطبيقات المثبتة"),this::showInstalledApps));
        TextView rootTitle=label(t("Optional Root / Magisk mode","وضع الروت / Magisk الاختياري"),19,true);LinearLayout.LayoutParams rtp=new LinearLayout.LayoutParams(-1,-2);rtp.topMargin=22;content.addView(rootTitle,rtp);
        TextView rootInfo=label(t("With your explicit approval, Hoda Scripts can ask Magisk/SU to relax selected background limits for this app only: background app-ops and the Doze whitelist. This does not disable Android security, grant Accessibility automatically, or guarantee that every OEM restriction is removed. You can revert these changes here.","بموافقتك الصريحة، يمكن لـ Hoda Scripts طلب صلاحية Magisk/SU لتخفيف قيود خلفية محددة لهذا التطبيق فقط: صلاحيات تشغيل الخلفية وقائمة استثناء Doze. هذا لا يعطل حماية أندرويد ولا يمنح Accessibility تلقائيًا ولا يضمن إزالة كل قيود الشركة المصنعة. ويمكنك التراجع عن التغييرات من هنا."),13,false);rootInfo.setTextColor(muted);card(rootInfo);
        content.addView(button(t("Check Root access","فحص صلاحية الروت"),()->runRootOperation(0)));
        content.addView(button(t("Allow supported background exemptions (Root)","السماح بإزالة قيود الخلفية المدعومة (روت)"),()->confirmRootApply()));
        content.addView(button(t("Revert Hoda Scripts Root exemptions","التراجع عن استثناءات الروت الخاصة بالتطبيق"),()->confirmRootRevoke()));
        TextView backupTitle=label(t("Backup and recovery","النسخ الاحتياطي والاستعادة"),19,true);LinearLayout.LayoutParams backupParams=new LinearLayout.LayoutParams(-1,-2);backupParams.topMargin=22;content.addView(backupTitle,backupParams);
        TextView backupInfo=label(t("Create a complete backup of your Hoda shortcut library and folders, or restore it later. Restore replaces the current shortcut library after your confirmation. Runtime variables, permissions and Android settings are not included.","أنشئ نسخة احتياطية كاملة من مكتبة اختصارات Hoda والمجلدات، أو استعدها لاحقًا. الاستعادة تستبدل مكتبة الاختصارات الحالية بعد تأكيدك. لا تشمل النسخة متغيرات التشغيل أو الصلاحيات أو إعدادات أندرويد."),13,false);backupInfo.setTextColor(muted);card(backupInfo);
        content.addView(button(t("Create full library backup","إنشاء نسخة احتياطية كاملة للمكتبة"),this::chooseBackupDestination));
        content.addView(button(t("Restore library from backup","استعادة المكتبة من نسخة احتياطية"),this::chooseBackupSource));
        TextView diagnosticsTitle=label(t("Diagnostics and support","التشخيص والدعم"),19,true);LinearLayout.LayoutParams dtp=new LinearLayout.LayoutParams(-1,-2);dtp.topMargin=22;content.addView(diagnosticsTitle,dtp);
        TextView diagnosticsInfo=label(t("Create a privacy-conscious report with app, Android, permission and run-count status. It does not include shortcut names, action data, variables or file contents.","أنشئ تقريرًا يحترم الخصوصية ويعرض حالة التطبيق وأندرويد والصلاحيات وعدد مرات التشغيل. لا يتضمن أسماء الاختصارات أو بيانات الإجراءات أو المتغيرات أو محتويات الملفات."),13,false);diagnosticsInfo.setTextColor(muted);card(diagnosticsInfo);
        content.addView(button(t("Run diagnostics / Share report","فحص التطبيق / مشاركة التقرير"),this::showDiagnosticsReport));
        TextView about=label("Hoda Scripts 0.12.0\n"+t("Root mode is optional and only runs after the Magisk/SU authorization prompt. Changes are limited to this app package.","وضع الروت اختياري ولا يعمل إلا بعد ظهور طلب موافقة Magisk/SU. التغييرات محدودة بحزمة هذا التطبيق."),13,false);about.setTextColor(muted);card(about);
    }
    private void chooseBackupDestination(){
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.putExtra(Intent.EXTRA_TITLE,"HodaScripts-Backup.json");startActivityForResult(intent,REQ_BACKUP_CREATE);
    }
    private void chooseBackupSource(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/json");intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(intent,REQ_BACKUP_RESTORE);
    }
    private JSONObject buildFullBackup() throws JSONException {
        JSONArray shortcuts=new JSONArray();
        for(Shortcut shortcut:store.all()){
            JSONObject item=new JSONObject();item.put("name",shortcut.name);item.put("icon",shortcut.icon);item.put("color",shortcut.color);item.put("folder",shortcut.folder);item.put("favorite",shortcut.favorite);item.put("actions",shortcut.actions);shortcuts.put(item);
        }
        JSONArray folders=new JSONArray();for(String folder:store.folders())folders.put(folder);
        JSONObject backup=new JSONObject();backup.put("format","hoda-full-backup-v1");backup.put("appVersion","0.12.0");backup.put("createdAt",System.currentTimeMillis());backup.put("folders",folders);backup.put("shortcuts",shortcuts);return backup;
    }
    private void writeFullBackup(Uri destination){
        try(java.io.OutputStream out=getContentResolver().openOutputStream(destination,"w")){
            if(out==null)throw new IllegalStateException("Cannot create backup file");
            out.write(buildFullBackup().toString(2).getBytes(java.nio.charset.StandardCharsets.UTF_8));out.flush();
            Toast.makeText(this,t("Backup created successfully","تم إنشاء النسخة الاحتياطية بنجاح"),Toast.LENGTH_LONG).show();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle(t("Backup failed","فشل النسخ الاحتياطي")).setMessage(String.valueOf(e.getMessage())).setPositiveButton(t("OK","حسنًا"),null).show();}
    }
    private void confirmFullRestore(Uri source){
        new AlertDialog.Builder(this).setTitle(t("Replace current library?","استبدال المكتبة الحالية؟"))
            .setMessage(t("Restoring this backup replaces all current shortcuts and folders. Export a backup of your current library first if you may need it. Continue?","استعادة النسخة ستستبدل كل الاختصارات والمجلدات الحالية. صدّر نسخة من مكتبتك الحالية أولًا إذا كنت قد تحتاجها. هل تريد المتابعة؟"))
            .setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Restore","استعادة"),(d,w)->readAndRestoreBackup(source)).show();
    }
    private void readAndRestoreBackup(Uri source){
        try(java.io.InputStream in=getContentResolver().openInputStream(source);java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){
            if(in==null)throw new IllegalStateException("Cannot open backup file");byte[] buffer=new byte[8192];int count,total=0;
            while((count=in.read(buffer))!=-1){total+=count;if(total>5*1024*1024)throw new IllegalArgumentException("Backup file exceeds 5 MB");out.write(buffer,0,count);}
            JSONObject root=new JSONObject(new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8));
            if(!"hoda-full-backup-v1".equals(root.optString("format")))throw new JSONException("Unsupported backup format");
            JSONArray shortcutArray=root.optJSONArray("shortcuts"),folderArray=root.optJSONArray("folders");
            if(shortcutArray==null||folderArray==null)throw new JSONException("Backup is missing library data");
            if(shortcutArray.length()>500||folderArray.length()>200)throw new IllegalArgumentException("Backup contains too many items");
            List<String> folders=new ArrayList<>();for(int i=0;i<folderArray.length();i++){String name=folderArray.optString(i,"").trim();if(!name.isEmpty())folders.add(name);}
            List<Shortcut> restored=new ArrayList<>();
            for(int i=0;i<shortcutArray.length();i++){
                JSONObject item=shortcutArray.optJSONObject(i);if(item==null)throw new JSONException("Invalid shortcut at index "+i);
                String name=item.optString("name","").trim();JSONArray actions=item.optJSONArray("actions");if(name.isEmpty()||name.length()>160||actions==null||actions.length()>1000)throw new JSONException("Invalid shortcut data at index "+i);
                for(int j=0;j<actions.length();j++){JSONObject action=actions.optJSONObject(j);if(action==null||action.optString("type","").trim().isEmpty())throw new JSONException("Invalid action in shortcut "+name);}
                String folder=item.optString("folder","").trim();if(folder.length()>160)throw new JSONException("Folder name is too long");if(!folder.isEmpty()&&!folders.contains(folder))folders.add(folder);if(folders.size()>200)throw new IllegalArgumentException("Backup contains more than 200 folders");
                restored.add(new Shortcut(0,name,item.optString("color","#EAE5FF"),item.optString("icon","⚡"),folder,item.optBoolean("favorite",false),actions,System.currentTimeMillis()));
            }
            store.replaceAll(restored,folders);com.hoda.scripts.widget.HodaWidgetProvider.refresh(this);
            Toast.makeText(this,t("Restored ","تمت استعادة ")+restored.size()+t(" shortcuts"," اختصارًا"),Toast.LENGTH_LONG).show();showHome();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle(t("Restore failed","فشلت الاستعادة")).setMessage(t("The backup was not applied: ","لم يتم تطبيق النسخة الاحتياطية: ")+e.getMessage()).setPositiveButton(t("OK","حسنًا"),null).show();}
    }

    private void showDiagnosticsReport(){
        String report=com.hoda.scripts.diagnostics.DiagnosticsReport.build(this);
        new AlertDialog.Builder(this).setTitle(t("Hoda Scripts diagnostics","تشخيص Hoda Scripts")).setMessage(report)
            .setNeutralButton(t("Copy","نسخ"),(d,w)->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null)cm.setPrimaryClip(android.content.ClipData.newPlainText("Hoda diagnostics",report));Toast.makeText(this,t("Report copied","تم نسخ التقرير"),Toast.LENGTH_SHORT).show();})
            .setPositiveButton(t("Share","مشاركة"),(d,w)->{Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");share.putExtra(Intent.EXTRA_SUBJECT,"Hoda Scripts diagnostics");share.putExtra(Intent.EXTRA_TEXT,report);startActivity(Intent.createChooser(share,t("Share diagnostics","مشاركة تقرير التشخيص")));})
            .setNegativeButton(t("Close","إغلاق"),null).show();
    }
    private void startVoiceShortcut(){
        Intent intent=new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE,arabic?"ar":"en-US");
        intent.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT,t("Say the shortcut name","قل اسم الاختصار"));
        try{startActivityForResult(intent,REQ_VOICE_SHORTCUT);}catch(Exception e){new AlertDialog.Builder(this).setMessage(t("No speech recognition app is available on this device.","لا يوجد تطبيق للتعرف على الكلام متاح على هذا الجهاز.")).setPositiveButton(t("OK","حسنًا"),null).show();}
    }
    private void runVoiceMatch(String spoken){
        if(spoken==null||spoken.trim().isEmpty())return;
        String wanted=spoken.trim();Shortcut exact=null;List<Shortcut> all=store.all();
        for(Shortcut item:all)if(item.name.trim().equalsIgnoreCase(wanted)){exact=item;break;}
        if(exact!=null){Shortcut selected=exact;new AlertDialog.Builder(this).setTitle(t("Run shortcut?","تشغيل الاختصار؟")).setMessage(selected.name).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Run","تشغيل"),(d,w)->runShortcut(selected)).show();return;}
        ArrayList<Shortcut> candidates=new ArrayList<>();String normalized=wanted.toLowerCase(Locale.ROOT);
        for(Shortcut item:all)if(item.name.toLowerCase(Locale.ROOT).contains(normalized)||normalized.contains(item.name.toLowerCase(Locale.ROOT)))candidates.add(item);
        if(candidates.size()==1){Shortcut selected=candidates.get(0);new AlertDialog.Builder(this).setTitle(t("Did you mean this shortcut?","هل تقصد هذا الاختصار؟")).setMessage(selected.name).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Run","تشغيل"),(d,w)->runShortcut(selected)).show();return;}
        if(candidates.size()>1){String[] names=new String[candidates.size()];for(int i=0;i<candidates.size();i++)names[i]=candidates.get(i).name;new AlertDialog.Builder(this).setTitle(t("Choose a shortcut","اختر اختصارًا")).setItems(names,(d,w)->{Shortcut selected=candidates.get(w);new AlertDialog.Builder(this).setMessage(t("Run ","تشغيل ")+selected.name+"?").setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Run","تشغيل"),(x,y)->runShortcut(selected)).show();}).show();return;}
        Toast.makeText(this,t("No matching shortcut: ","لم يتم العثور على اختصار مطابق: ")+wanted,Toast.LENGTH_LONG).show();
    }
    private void showRunHistory(){
        org.json.JSONArray history=com.hoda.scripts.data.RunHistoryStore.get(this);
        if(history.length()==0){new AlertDialog.Builder(this).setTitle(t("Execution history","سجل التشغيل")).setMessage(t("No shortcut runs have been recorded yet.","لا توجد عمليات تشغيل مسجلة حتى الآن.")).setPositiveButton(t("OK","حسنًا"),null).show();return;}
        String[] lines=new String[history.length()];java.text.DateFormat date=java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT,java.text.DateFormat.SHORT);
        for(int i=0;i<history.length();i++){org.json.JSONObject item=history.optJSONObject(i);if(item==null){lines[i]="";continue;}String state=item.optBoolean("success")?"✓ ":"✕ ";lines[i]=state+item.optString("name")+"\n"+date.format(new java.util.Date(item.optLong("time")))+" · "+item.optString("detail");}
        new AlertDialog.Builder(this).setTitle(t("Recent executions","عمليات التشغيل الأخيرة")).setItems(lines,null).setNeutralButton(t("Clear history","مسح السجل"),(d,w)->new AlertDialog.Builder(this).setMessage(t("Clear all execution history?","هل تريد مسح سجل التشغيل بالكامل؟")).setNegativeButton(t("Cancel","إلغاء"),null).setPositiveButton(t("Clear","مسح"),(x,y)->{com.hoda.scripts.data.RunHistoryStore.clear(this);Toast.makeText(this,t("History cleared","تم مسح السجل"),Toast.LENGTH_SHORT).show();}).show()).setPositiveButton(t("Close","إغلاق"),null).show();
    }
    private boolean isHodaAccessibilityEnabled(){
        try{String enabled=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);if(enabled==null)return false;String target=new ComponentName(this,com.hoda.scripts.accessibility.HodaAccessibilityService.class).flattenToString();for(String item:enabled.split(":"))if(target.equalsIgnoreCase(item))return true;}catch(Exception ignored){}return false;
    }
    private void showInstalledApps(){
        Intent query=new Intent(Intent.ACTION_MAIN);query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> apps=getPackageManager().queryIntentActivities(query,0);
        Collections.sort(apps,(a,b)->String.valueOf(a.loadLabel(getPackageManager())).compareToIgnoreCase(String.valueOf(b.loadLabel(getPackageManager()))));
        List<android.content.pm.ResolveInfo> visible=new ArrayList<>();for(android.content.pm.ResolveInfo info:apps)if(info.activityInfo!=null&&!getPackageName().equals(info.activityInfo.packageName))visible.add(info);
        if(visible.isEmpty()){Toast.makeText(this,t("No launchable apps found","لم يتم العثور على تطبيقات قابلة للتشغيل"),Toast.LENGTH_SHORT).show();return;}
        String[] labels=new String[visible.size()];for(int i=0;i<visible.size();i++)labels[i]=visible.get(i).loadLabel(getPackageManager())+"  ·  "+visible.get(i).activityInfo.packageName;
        new AlertDialog.Builder(this).setTitle(t("Installed apps","التطبيقات المثبتة")).setItems(labels,(d,which)->{String pkg=visible.get(which).activityInfo.packageName;new AlertDialog.Builder(this).setTitle(labels[which]).setMessage(t("Package name (use this in the Open App action): ","اسم الحزمة (استخدمه في إجراء فتح تطبيق): ")+pkg).setPositiveButton(t("Copy","نسخ"),(x,y)->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText("package",pkg));Toast.makeText(this,t("Package copied","تم نسخ اسم الحزمة"),Toast.LENGTH_SHORT).show();}).setNegativeButton(t("Close","إغلاق"),null).show();}).setNegativeButton(t("Close","إغلاق"),null).show();
    }
    private void confirmRootApply(){
        new AlertDialog.Builder(this)
            .setTitle(t("Allow Root background exemptions?","السماح باستثناءات الخلفية عبر الروت؟"))
            .setMessage(t("Hoda Scripts will request SU permission. If approved, it will change only this app's RUN_IN_BACKGROUND and RUN_ANY_IN_BACKGROUND app-ops and add this package to the Doze whitelist. It will not change other apps or disable SELinux/system security. Some commands may not be supported by your ROM. Continue?","سيطلب Hoda Scripts صلاحية SU. إذا وافقت، سيغيّر إعدادَي RUN_IN_BACKGROUND وRUN_ANY_IN_BACKGROUND لهذا التطبيق فقط، ويضيف حزمة التطبيق إلى قائمة استثناء Doze. لن يغيّر التطبيقات الأخرى أو يعطّل SELinux أو حماية النظام. قد لا تدعم نسختك بعض الأوامر. هل تريد المتابعة؟"))
            .setNegativeButton(t("Cancel","إلغاء"),null)
            .setPositiveButton(t("I approve","أوافق"),(d,w)->runRootOperation(1)).show();
    }
    private void confirmRootRevoke(){
        new AlertDialog.Builder(this)
            .setTitle(t("Revert Root changes?","التراجع عن تغييرات الروت؟"))
            .setMessage(t("Restore the app-ops to their default mode and remove Hoda Scripts from the Doze whitelist?","إعادة إعدادات تشغيل الخلفية إلى الوضع الافتراضي وإزالة Hoda Scripts من قائمة استثناء Doze؟"))
            .setNegativeButton(t("Cancel","إلغاء"),null)
            .setPositiveButton(t("Revert","تراجع"),(d,w)->runRootOperation(2)).show();
    }
    private void runRootOperation(int operation){
        Toast.makeText(this,t("Waiting for Magisk / SU authorization…","في انتظار موافقة Magisk / SU…"),Toast.LENGTH_LONG).show();
        new Thread(()->{
            RootAccessManager.Result result;
            if(operation==1)result=RootAccessManager.applyBackgroundExemptions(getApplicationContext());
            else if(operation==2)result=RootAccessManager.revokeBackgroundExemptions(getApplicationContext());
            else result=RootAccessManager.checkRoot();
            String message;
            if(!result.rootGranted)message=t("Root was not granted. No root changes were made.","لم تتم الموافقة على الروت. لم تُجرَ أي تغييرات.");
            else if(operation==0)message=t("Root access is available.","صلاحية الروت متاحة.");
            else message=t("Root commands: ","أوامر الروت: ")+result.successfulCommands+t(" succeeded, "," نجحت، ")+result.failedCommands+t(" failed."," فشلت.");
            final String shown=message;
            handler.post(()->new AlertDialog.Builder(this).setTitle(t("Root operation result","نتيجة عملية الروت")).setMessage(shown).setPositiveButton(t("OK","حسنًا"),null).show());
        }).start();
    }
    private void enableBackgroundEngine(){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},REQ_NOTIFICATIONS);return;}
        startAutomationService();
    }
    private void startAutomationService(){
        Intent i=new Intent(this,com.hoda.scripts.engine.AutomationService.class);i.setAction(com.hoda.scripts.engine.AutomationService.ACTION_START);
        try{if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);Toast.makeText(this,t("Background engine enabled","تم تفعيل محرك الخلفية"),Toast.LENGTH_SHORT).show();}
        catch(Exception e){Toast.makeText(this,t("Could not start background engine: ","تعذر تشغيل محرك الخلفية: ")+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void openAppDetails(){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==REQ_NOTIFICATIONS){if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)startAutomationService();else Toast.makeText(this,t("Notification permission is needed for a visible background engine","يلزم السماح بالإشعارات لتشغيل محرك الخلفية بشكل ظاهر"),Toast.LENGTH_LONG).show();}}

}
