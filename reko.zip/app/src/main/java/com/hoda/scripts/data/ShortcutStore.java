package com.hoda.scripts.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.hoda.scripts.model.Shortcut;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Durable library storage: shortcuts, folders, favourites and ordering metadata. */
public class ShortcutStore extends SQLiteOpenHelper {
    public ShortcutStore(Context c) { super(c, "hoda_scripts.db", null, 2); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE shortcuts (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, color TEXT NOT NULL, icon TEXT NOT NULL, actions TEXT NOT NULL, updated_at INTEGER NOT NULL, folder TEXT NOT NULL DEFAULT '', favorite INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE folders (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created_at INTEGER NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE shortcuts ADD COLUMN folder TEXT NOT NULL DEFAULT ''");
            db.execSQL("ALTER TABLE shortcuts ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0");
            db.execSQL("CREATE TABLE IF NOT EXISTS folders (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created_at INTEGER NOT NULL)");
        }
    }

    public long save(Shortcut s) {
        SQLiteDatabase db=getWritableDatabase(); ContentValues v=new ContentValues();
        v.put("name",s.name); v.put("color",s.color); v.put("icon",s.icon);
        v.put("actions",s.actions.toString()); v.put("updated_at",System.currentTimeMillis());
        v.put("folder",s.folder); v.put("favorite",s.favorite?1:0);
        if(s.id>0) { int n=db.update("shortcuts",v,"_id=?",new String[]{String.valueOf(s.id)}); if(n>0)return s.id; }
        return db.insert("shortcuts",null,v);
    }

    public List<Shortcut> all() {
        List<Shortcut> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT _id,name,color,icon,actions,updated_at,folder,favorite FROM shortcuts ORDER BY updated_at DESC",null)) {
            while(c.moveToNext()) out.add(fromCursor(c));
        }
        return out;
    }

    private Shortcut fromCursor(Cursor c) {
        JSONArray a; try { a=new JSONArray(c.getString(4)); } catch(JSONException e){a=new JSONArray();}
        return new Shortcut(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(6),c.getInt(7)==1,a,c.getLong(5));
    }

    public Shortcut get(long id) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT _id,name,color,icon,actions,updated_at,folder,favorite FROM shortcuts WHERE _id=?",new String[]{String.valueOf(id)})) {
            return c.moveToFirst()?fromCursor(c):null;
        }
    }

    public void delete(long id) { getWritableDatabase().delete("shortcuts","_id=?",new String[]{String.valueOf(id)}); }

    public long duplicate(long id) {
        Shortcut source=get(id); if(source==null)return -1;
        Shortcut copy=new Shortcut(0,source.name+" (copy)",source.color,source.icon,source.folder,source.favorite,cloneActions(source.actions),0);
        return save(copy);
    }

    private JSONArray cloneActions(JSONArray source) {
        try { return new JSONArray(source.toString()); } catch(JSONException e) { return new JSONArray(); }
    }

    /** Replace the complete library atomically after a validated backup has been parsed. */
    public void replaceAll(List<Shortcut> shortcuts, List<String> folderNames) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("shortcuts", null, null);
            db.delete("folders", null, null);
            if (folderNames != null) {
                for (String name : folderNames) {
                    String clean = name == null ? "" : name.trim();
                    if (!clean.isEmpty()) {
                        ContentValues folder = new ContentValues();
                        folder.put("name", clean);
                        folder.put("created_at", System.currentTimeMillis());
                        db.insertWithOnConflict("folders", null, folder, SQLiteDatabase.CONFLICT_IGNORE);
                    }
                }
            }
            if (shortcuts != null) {
                for (Shortcut shortcut : shortcuts) {
                    if (shortcut == null) continue;
                    ContentValues values = new ContentValues();
                    values.put("name", shortcut.name);
                    values.put("color", shortcut.color);
                    values.put("icon", shortcut.icon);
                    values.put("actions", shortcut.actions.toString());
                    values.put("updated_at", System.currentTimeMillis());
                    values.put("folder", shortcut.folder);
                    values.put("favorite", shortcut.favorite ? 1 : 0);
                    db.insertOrThrow("shortcuts", null, values);
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public List<String> folders() {
        Set<String> names=new LinkedHashSet<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT name FROM folders ORDER BY name COLLATE NOCASE",null)) { while(c.moveToNext())names.add(c.getString(0)); }
        try(Cursor c=getReadableDatabase().rawQuery("SELECT DISTINCT folder FROM shortcuts WHERE folder<>'' ORDER BY folder COLLATE NOCASE",null)) { while(c.moveToNext())names.add(c.getString(0)); }
        return new ArrayList<>(names);
    }

    public boolean createFolder(String name) {
        String clean=name==null?"":name.trim(); if(clean.isEmpty())return false;
        ContentValues v=new ContentValues();v.put("name",clean);v.put("created_at",System.currentTimeMillis());
        return getWritableDatabase().insertWithOnConflict("folders",null,v,SQLiteDatabase.CONFLICT_IGNORE)>0;
    }

    public void renameFolder(String oldName,String newName) {
        String clean=newName==null?"":newName.trim();if(clean.isEmpty())return;
        try(Cursor existing=getReadableDatabase().rawQuery("SELECT 1 FROM folders WHERE name=? AND name<>?",new String[]{clean,oldName})){if(existing.moveToFirst())return;}
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try { ContentValues f=new ContentValues();f.put("name",clean);db.update("folders",f,"name=?",new String[]{oldName});ContentValues s=new ContentValues();s.put("folder",clean);db.update("shortcuts",s,"folder=?",new String[]{oldName});db.setTransactionSuccessful(); }
        finally { db.endTransaction(); }
    }

    public void deleteFolder(String name) {
        SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("folder","");db.update("shortcuts",v,"folder=?",new String[]{name});db.delete("folders","name=?",new String[]{name});
    }
}
