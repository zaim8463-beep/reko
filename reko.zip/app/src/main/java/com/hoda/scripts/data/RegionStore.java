package com.hoda.scripts.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.hoda.scripts.model.ScreenRegion;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Durable JSON store for named screen regions. */
public final class RegionStore {
    private static final String PREF="hoda_regions", KEY="items";
    private final SharedPreferences prefs;
    public RegionStore(Context c){prefs=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    public List<ScreenRegion> all(){
        List<ScreenRegion> out=new ArrayList<>();
        try{JSONArray a=new JSONArray(prefs.getString(KEY,"[]"));
            for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(from(o));}
        }catch(Exception ignored){}
        java.util.Collections.sort(out,(a,b)->Long.compare(b.updatedAt,a.updatedAt)); return out;
    }
    public ScreenRegion get(long id){for(ScreenRegion r:all())if(r.id==id)return r;return null;}
    public long save(ScreenRegion r){
        List<ScreenRegion> list=all(); if(r.id<=0)r.id=System.currentTimeMillis();
        r.updatedAt=System.currentTimeMillis(); boolean replaced=false;
        for(int i=0;i<list.size();i++)if(list.get(i).id==r.id){list.set(i,r);replaced=true;break;}
        if(!replaced)list.add(r); write(list); return r.id;
    }
    public void delete(long id){List<ScreenRegion> list=all();list.removeIf(r->r.id==id);write(list);}
    private void write(List<ScreenRegion> list){JSONArray a=new JSONArray();try{for(ScreenRegion r:list)a.put(to(r));}catch(Exception ignored){}prefs.edit().putString(KEY,a.toString()).apply();}
    private JSONObject to(ScreenRegion r)throws Exception{
        JSONObject o=new JSONObject();o.put("id",r.id);o.put("name",r.name);o.put("color",r.color);
        o.put("x",r.x);o.put("y",r.y);o.put("width",r.width);o.put("height",r.height);
        o.put("tapDurationMs",r.tapDurationMs);o.put("tapSpeedMs",r.tapSpeedMs);
        o.put("holdDurationMs",r.holdDurationMs);o.put("swipeDurationMs",r.swipeDurationMs);
        o.put("swipeSpeedPxPerSec",r.swipeSpeedPxPerSec);o.put("repetitions",r.repetitions);
        o.put("intervalMs",r.intervalMs);o.put("actionMode",r.actionMode);
        o.put("iconTapDurationMs",r.iconTapDurationMs);o.put("iconLongPressDurationMs",r.iconLongPressDurationMs);
        o.put("iconDoubleTapDurationMs",r.iconDoubleTapDurationMs);o.put("updatedAt",r.updatedAt);return o;
    }
    private ScreenRegion from(JSONObject o){
        return new ScreenRegion(o.optLong("id"),o.optString("name","Region"),o.optString("color","#EAE5FF"),
            o.optInt("x"),o.optInt("y"),o.optInt("width",1),o.optInt("height",1),
            o.optLong("tapDurationMs",80),o.optLong("tapSpeedMs",0),o.optLong("holdDurationMs",500),
            o.optLong("swipeDurationMs",200),o.optLong("swipeSpeedPxPerSec",0),o.optInt("repetitions",1),
            o.optLong("intervalMs",0),o.optString("actionMode","tap"),
            o.optLong("iconTapDurationMs",80),o.optLong("iconLongPressDurationMs",500),
            o.optLong("iconDoubleTapDurationMs",300),o.optLong("updatedAt",0));
    }
}
